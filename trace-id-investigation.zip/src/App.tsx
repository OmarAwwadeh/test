import { useState, useEffect, useCallback } from 'react';
import { Character, Scene, Episode, Project, WorkflowSettings, Connections } from './types';
import { STYLE_PRESETS, CAMERA_MOVEMENTS, MOODS, CHARACTER_COLORS, SETUP_GUIDE, TROUBLESHOOTING } from './constants';
import { generateWorkflow } from './workflow';

/* ── helpers ── */
function StatusDot({ status }: { status: 'connected' | 'disconnected' | 'checking' }) {
  const cls =
    status === 'connected' ? 'bg-green-400 shadow-green-400/50' :
    status === 'checking' ? 'bg-yellow-400 shadow-yellow-400/50 animate-pulse' :
    'bg-red-500 shadow-red-500/50';
  return <span className={`inline-block w-2.5 h-2.5 rounded-full ${cls} shadow-md`} />;
}

function Badge({ children, color = 'gray' }: { children: React.ReactNode; color?: string }) {
  const map: Record<string, string> = {
    gray: 'bg-gray-700 text-gray-200',
    green: 'bg-green-900/60 text-green-300',
    red: 'bg-red-900/60 text-red-300',
    yellow: 'bg-yellow-900/60 text-yellow-300',
    blue: 'bg-blue-900/60 text-blue-300',
    purple: 'bg-purple-900/60 text-purple-300',
  };
  return <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${map[color] ?? map.gray}`}>{children}</span>;
}

function SceneStatusBadge({ status }: { status: Scene['status'] }) {
  if (status === 'done') return <Badge color="green">✓ Done</Badge>;
  if (status === 'generating') return <Badge color="yellow">⟳ Generating</Badge>;
  if (status === 'error') return <Badge color="red">✗ Error</Badge>;
  return <Badge color="gray">○ Pending</Badge>;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <button
      onClick={() => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 1500); }}
      className="text-xs px-2 py-0.5 rounded bg-gray-600 hover:bg-gray-500 text-gray-300 transition-colors"
    >
      {copied ? '✓ Copied' : 'Copy'}
    </button>
  );
}

/* ─────────────────────────── MAIN APP ─────────────────────────── */
export default function App() {
  const [activeTab, setActiveTab] = useState<'dashboard' | 'create' | 'project' | 'settings' | 'guide' | 'troubleshoot'>('dashboard');
  const [projects, setProjects] = useState<Project[]>(() => {
    try { return JSON.parse(localStorage.getItem('ltx2-agent-projects') || '[]'); } catch { return []; }
  });
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [showLog, setShowLog] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [expandedGuide, setExpandedGuide] = useState<number | null>(null);

  const [connections, setConnections] = useState<Connections>({
    comfyui: 'disconnected', ollama: 'disconnected',
    comfyuiUrl: 'http://127.0.0.1:8188', ollamaUrl: 'http://127.0.0.1:11434',
    comfyuiModels: [], comfyuiVAEs: [], ollamaModels: [],
    hasVHS: false, hasGGUF: false, gpu: 'Unknown', gpuMemory: 'Unknown',
  });

  const [settings, setSettings] = useState<WorkflowSettings>({
    width: 512, height: 384, fps: 24, steps: 8, cfg: 3.0,
    sampler: 'euler', scheduler: 'normal',
    modelFile: 'ltx-video-2b-Q4_K_M.gguf', vaeFile: 'ltx-video-2b.safetensors',
  });

  useEffect(() => { localStorage.setItem('ltx2-agent-projects', JSON.stringify(projects)); }, [projects]);

  const addLog = useCallback((msg: string) => {
    const time = new Date().toLocaleTimeString();
    setLogs(prev => [`[${time}] ${msg}`, ...prev.slice(0, 80)]);
  }, []);

  /* ── Connections ── */
  const checkConnections = useCallback(async () => {
    setConnections(p => ({ ...p, comfyui: 'checking', ollama: 'checking' }));
    addLog('🔍 Checking connections...');

    // ComfyUI
    try {
      const res = await fetch(`${connections.comfyuiUrl}/system_stats`);
      if (res.ok) {
        const data = await res.json();
        const gpuName = data.devices?.[0]?.name || 'GPU';
        const gpuMem = data.devices?.[0]?.vram_total
          ? `${(data.devices[0].vram_total / 1073741824).toFixed(1)}GB` : '?';
        addLog(`✅ ComfyUI connected — ${gpuName} (${gpuMem})`);
        try {
          const objRes = await fetch(`${connections.comfyuiUrl}/object_info`);
          const objData = await objRes.json();
          const checkpoints = objData.CheckpointLoaderSimple?.input?.required?.ckpt_name?.[0] || [];
          const unets = objData.UnetLoaderGGUF?.input?.required?.unet_name?.[0] || [];
          const vaes = objData.VAELoader?.input?.required?.vae_name?.[0] || [];
          const allModels = [...checkpoints, ...unets];
          const hasVHS = !!objData.VHS_VideoCombine;
          const hasGGUF = !!objData.UnetLoaderGGUF;
          setConnections(p => ({ ...p, comfyui: 'connected', comfyuiModels: allModels, comfyuiVAEs: vaes, hasVHS, hasGGUF, gpu: gpuName, gpuMemory: gpuMem }));
          if (!hasVHS) addLog('⚠️ VHS_VideoCombine not found — install ComfyUI-VideoHelperSuite');
          if (!hasGGUF) addLog('ℹ️ GGUF node not found — only checkpoint models available');
          if (allModels.length === 0) addLog('⚠️ No models found — place .gguf files in models/unet/');
          if (vaes.length === 0) addLog('⚠️ No VAE found — place ltx-video-2b.safetensors in models/vae/');
        } catch { setConnections(p => ({ ...p, comfyui: 'connected' })); }
      } else {
        setConnections(p => ({ ...p, comfyui: 'disconnected' }));
        addLog('❌ ComfyUI not responding');
      }
    } catch {
      setConnections(p => ({ ...p, comfyui: 'disconnected' }));
      addLog('❌ Cannot connect to ComfyUI — is it running on port 8188?');
    }

    // Ollama
    try {
      const res = await fetch(`${connections.ollamaUrl}/api/tags`);
      if (res.ok) {
        const data = await res.json();
        const models = data.models?.map((m: { name: string }) => m.name) || [];
        setConnections(p => ({ ...p, ollama: 'connected', ollamaModels: models }));
        addLog(`✅ Ollama connected${models.length > 0 ? ` — ${models.length} model(s)` : ' — no models'}`);
        if (models.length === 0) addLog('💡 Run: ollama pull llama3.2');
      } else {
        setConnections(p => ({ ...p, ollama: 'disconnected' }));
        addLog('❌ Ollama not responding');
      }
    } catch {
      setConnections(p => ({ ...p, ollama: 'disconnected' }));
      addLog('❌ Cannot connect to Ollama — is it running on port 11434?');
    }
  }, [connections.comfyuiUrl, connections.ollamaUrl, addLog]);

  useEffect(() => { const t = setTimeout(checkConnections, 600); return () => clearTimeout(t); }, []); // eslint-disable-line

  /* ── Ollama helper ── */
  const askOllama = async (prompt: string): Promise<string> => {
    try {
      const model = connections.ollamaModels[0] || 'llama3.2';
      const res = await fetch(`${connections.ollamaUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ model, prompt, stream: false, options: { temperature: 0.7, num_predict: 4000 } }),
      });
      const data = await res.json();
      return data.response || '';
    } catch { addLog('❌ Ollama generation failed'); return ''; }
  };

  /* ── AI Generate Characters ── */
  const aiGenerateCharacters = async () => {
    if (!selectedProject || connections.ollama !== 'connected') return;
    setAiGenerating(true);
    addLog('🤖 Generating characters with AI...');
    const prompt = `Create exactly 4 unique anime characters for "${selectedProject.name}" (${selectedProject.style} style).\nDescription: ${selectedProject.description}\n\nUse EXACTLY this format for each character:\n\nCHARACTER: [Name]\nROLE: [protagonist/antagonist/supporting/minor]\nAPPEARANCE: [detailed visual: hair color/style, eye color, clothing, distinguishing features]\nCONSISTENT: [short phrase for consistent rendering]\n\nMake characters visually distinct and memorable.`;
    const response = await askOllama(prompt);
    const blocks = response.split(/CHARACTER:/i).filter((b: string) => b.trim());
    const newChars: Character[] = [];
    for (const block of blocks.slice(0, 4)) {
      const lines = block.trim().split('\n').map((l: string) => l.trim()).filter(Boolean);
      const name = lines[0]?.replace(/[:.]/g, '').trim() || '';
      const getVal = (key: string) => {
        const line = lines.find((l: string) => l.toLowerCase().startsWith(key.toLowerCase() + ':'));
        return line?.split(':').slice(1).join(':').trim() || '';
      };
      const roleStr = getVal('ROLE').toLowerCase();
      const role: Character['role'] = roleStr.includes('protagonist') ? 'protagonist'
        : roleStr.includes('antagonist') ? 'antagonist'
        : roleStr.includes('minor') ? 'minor' : 'supporting';
      const appearance = getVal('APPEARANCE') || 'anime character';
      const consistent = getVal('CONSISTENT') || `same ${name} character`;
      if (name.length > 1 && name.length < 30) {
        newChars.push({
          id: `char_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          name, appearance, role, consistentPrompt: consistent,
          color: CHARACTER_COLORS[(selectedProject.characters.length + newChars.length) % CHARACTER_COLORS.length],
        });
      }
    }
    if (newChars.length === 0) {
      addLog('⚠️ Could not parse characters, creating defaults');
      newChars.push(
        { id: `char_${Date.now()}_1`, name: 'Hero', appearance: 'determined young warrior with spiky dark hair and bright eyes', role: 'protagonist', consistentPrompt: 'same hero character', color: CHARACTER_COLORS[0] },
        { id: `char_${Date.now()}_2`, name: 'Rival', appearance: 'cool antagonist with silver hair and sharp gaze', role: 'antagonist', consistentPrompt: 'same rival character', color: CHARACTER_COLORS[4] },
      );
    }
    const updated = { ...selectedProject, characters: [...selectedProject.characters, ...newChars] };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
    addLog(`✅ Generated ${newChars.length} characters`);
    setAiGenerating(false);
  };

  /* ── AI Generate Story ── */
  const aiGenerateStory = async () => {
    if (!selectedProject || connections.ollama !== 'connected') return;
    setAiGenerating(true);
    addLog('🤖 Generating episode story with AI...');
    const charDesc = selectedProject.characters.map(c => `- ${c.name} (${c.role}): ${c.appearance}`).join('\n');
    const prompt = `Create an anime episode with 5-8 scenes for "${selectedProject.name}" (${selectedProject.style}).\nStory: ${selectedProject.description}\n\nCharacters:\n${charDesc}\n\nFor each scene use EXACTLY this format:\n\nSCENE: [Title]\nDESCRIPTION: [what happens, 1-2 sentences]\nCHARACTERS: [character names present]\nCAMERA: [static shot/pan left/pan right/zoom in/zoom out/tracking shot]\nBACKGROUND: [detailed setting]\nMOOD: [Calm/Action/Dramatic/Romantic/Mysterious/Comedy/Sad/Epic]\nDURATION: [2-5 seconds number]\nDIALOGUE: [line or NONE]\n\nCreate a compelling story arc with beginning, middle, end.`;
    const response = await askOllama(prompt);
    const sceneBlocks = response.split(/SCENE:/i).filter((b: string) => b.trim());
    const newScenes: Scene[] = [];
    for (const block of sceneBlocks.slice(0, 8)) {
      const lines = block.trim().split('\n').map((l: string) => l.trim()).filter(Boolean);
      const title = lines[0]?.replace(/[:]/g, '').trim() || '';
      const getVal = (key: string) => {
        const line = lines.find((l: string) => l.toLowerCase().startsWith(key.toLowerCase() + ':'));
        return line?.split(':').slice(1).join(':').trim() || '';
      };
      const desc = getVal('DESCRIPTION') || 'A scene';
      const charNames = getVal('CHARACTERS') || '';
      const camera = getVal('CAMERA') || 'static shot';
      const background = getVal('BACKGROUND') || 'anime background';
      const mood = getVal('MOOD') || 'Calm and peaceful';
      const duration = Math.min(10, Math.max(2, parseInt(getVal('DURATION')) || 3));
      const dialogue = getVal('DIALOGUE') || '';
      const matchedChars = selectedProject.characters
        .filter(c => charNames.toLowerCase().includes(c.name.toLowerCase()))
        .map(c => c.id);
      if (matchedChars.length === 0) {
        const protag = selectedProject.characters.find(c => c.role === 'protagonist');
        if (protag) matchedChars.push(protag.id);
      }
      if (title.length > 1) {
        newScenes.push({
          id: `scene_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          title, description: desc, characters: matchedChars, camera, duration, background, mood,
          dialogue: dialogue.toUpperCase() === 'NONE' ? '' : dialogue,
          seed: Math.floor(Math.random() * 9999999999), status: 'pending', progress: 0,
        });
      }
    }
    if (newScenes.length === 0) {
      const protag = selectedProject.characters.find(c => c.role === 'protagonist');
      newScenes.push(
        { id: `scene_${Date.now()}_1`, title: 'Opening', description: 'The story begins', characters: protag ? [protag.id] : [], camera: 'slow pan right', duration: 3, background: 'anime landscape at dawn', mood: 'Calm and peaceful', dialogue: '', seed: Math.floor(Math.random() * 9999999999), status: 'pending', progress: 0 },
        { id: `scene_${Date.now()}_2`, title: 'Conflict', description: 'Something unexpected happens', characters: selectedProject.characters.slice(0, 2).map(c => c.id), camera: 'zoom in', duration: 4, background: 'dramatic interior', mood: 'Dramatic tension', dialogue: '', seed: Math.floor(Math.random() * 9999999999), status: 'pending', progress: 0 },
      );
      addLog('📝 Created 2 default scenes (AI parse failed)');
    }
    const newEp: Episode = { id: `ep_${Date.now()}`, title: `Episode ${selectedProject.episodes.length + 1}`, scenes: newScenes };
    const updated = { ...selectedProject, episodes: [...selectedProject.episodes, newEp] };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
    setSelectedEpisode(newEp.id);
    addLog(`✅ Generated ${newScenes.length} scenes`);
    setAiGenerating(false);
  };

  /* ── Queue scene ── */
  const queueScene = async (scene: Scene, epIndex: number, scIndex: number) => {
    if (connections.comfyui !== 'connected' || !selectedProject) { addLog('❌ ComfyUI not connected'); return; }
    const updateScene = (updates: Partial<Scene>) => {
      const upFn = (p: Project): Project => {
        const eps = p.episodes.map((e, ei) => ei !== epIndex ? e : {
          ...e, scenes: e.scenes.map((s, si) => si !== scIndex ? s : { ...s, ...updates }),
        });
        return { ...p, episodes: eps };
      };
      setProjects(prev => prev.map(p => p.id === selectedProject.id ? upFn(p) : p));
      setSelectedProject(prev => prev && prev.id === selectedProject.id ? upFn(prev) : prev);
    };
    updateScene({ status: 'generating', progress: 0, error: undefined });
    addLog(`🎬 Queuing: ${scene.title}`);
    try {
      let workflow = generateWorkflow(scene, settings, selectedProject, connections.hasVHS);
      const res = await fetch(`${connections.comfyuiUrl}/prompt`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: workflow }),
      });
      let result = await res.json();
      if (result.error) {
        if (result.error.type === 'missing_node_type' && result.error.message?.includes('VHS')) {
          addLog('⚠️ VHS not found, using SaveImage fallback...');
          workflow = generateWorkflow(scene, settings, selectedProject, false);
          const res2 = await fetch(`${connections.comfyuiUrl}/prompt`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ prompt: workflow }),
          });
          result = await res2.json();
          if (result.error) throw new Error(result.error.message || 'Fallback failed');
        } else { throw new Error(result.error.message || 'Workflow error'); }
      }
      if (!result.prompt_id) throw new Error('No prompt_id returned');
      addLog(`✅ Queued: ${scene.title} (ID: ${result.prompt_id})`);
      updateScene({ promptId: result.prompt_id });
      let attempts = 0;
      while (attempts < 600) {
        await new Promise(r => setTimeout(r, 1000));
        attempts++;
        try {
          const histRes = await fetch(`${connections.comfyuiUrl}/history/${result.prompt_id}`);
          const histData = await histRes.json();
          if (histData[result.prompt_id]?.status?.completed) { updateScene({ status: 'done', progress: 100 }); addLog(`✅ Completed: ${scene.title}`); return; }
          if (histData[result.prompt_id]?.status?.status_str === 'error') throw new Error('ComfyUI generation error');
          updateScene({ progress: Math.min(95, Math.floor((attempts / 300) * 100)) });
        } catch (e) { if (e instanceof Error && e.message.includes('ComfyUI')) throw e; }
      }
      throw new Error('Generation timeout (10 min)');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      updateScene({ status: 'error', progress: 0, error: msg });
      addLog(`❌ Failed: ${scene.title} — ${msg}`);
    }
  };

  const generateEpisode = async () => {
    if (!selectedProject || !selectedEpisode) return;
    const epIndex = selectedProject.episodes.findIndex(e => e.id === selectedEpisode);
    if (epIndex === -1) return;
    const episode = selectedProject.episodes[epIndex];
    setGenerating(true);
    addLog(`🎬 Starting episode: ${episode.title}`);
    for (let i = 0; i < episode.scenes.length; i++) {
      if (episode.scenes[i].status === 'done') continue;
      await queueScene(episode.scenes[i], epIndex, i);
      await new Promise(r => setTimeout(r, 500));
    }
    setGenerating(false);
    addLog(`✅ Episode complete: ${episode.title}`);
  };

  /* ── Download helpers ── */
  const downloadWorkflow = (scene: Scene) => {
    if (!selectedProject) return;
    const wf = generateWorkflow(scene, settings, selectedProject, connections.hasVHS);
    const blob = new Blob([JSON.stringify(wf, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `${scene.title.replace(/[^a-zA-Z0-9]/g, '_')}_workflow.json`; a.click();
    URL.revokeObjectURL(url); addLog(`📥 Downloaded workflow: ${scene.title}`);
  };

  const downloadBatchScript = () => {
    if (!selectedProject) return;
    const script = `@echo off\nREM LTX-2 Anime Video Batch Processor\nREM Project: ${selectedProject.name}\necho Starting batch video generation...\necho.\nset COMFYUI_URL=http://127.0.0.1:8188\n\n${selectedProject.episodes.map(ep => `REM === ${ep.title} ===\necho Processing ${ep.title}...\n${ep.scenes.map((sc) => `echo   Scene: ${sc.title}\ncurl -X POST %COMFYUI_URL%/prompt -H "Content-Type: application/json" -d @${sc.title.replace(/[^a-zA-Z0-9]/g, '_')}_workflow.json\ntimeout /t 5 /nobreak >nul`).join('\n')}`).join('\n\n')}\n\necho All scenes queued!\npause`;
    const blob = new Blob([script], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url; a.download = `${selectedProject.name.replace(/[^a-zA-Z0-9]/g, '_')}_batch.bat`; a.click();
    URL.revokeObjectURL(url); addLog('📥 Downloaded batch script');
  };

  /* ── Project CRUD ── */
  const createProject = (name: string, description: string, style: string) => {
    const p: Project = { id: `proj_${Date.now()}`, name, description, style, episodes: [], characters: [], createdAt: new Date().toISOString() };
    setProjects(prev => [...prev, p]);
    setSelectedProject(p);
    setSelectedEpisode(null);
    setActiveTab('project');
    addLog(`✅ Created project: ${name}`);
  };

  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(p => p.id !== id));
    if (selectedProject?.id === id) { setSelectedProject(null); setSelectedEpisode(null); }
    addLog('🗑️ Deleted project');
  };

  /* ── Character CRUD ── */
  const addCharacter = () => {
    if (!selectedProject) return;
    const char: Character = { id: `char_${Date.now()}`, name: 'New Character', appearance: '', color: CHARACTER_COLORS[selectedProject.characters.length % CHARACTER_COLORS.length], role: 'supporting', consistentPrompt: '' };
    const updated = { ...selectedProject, characters: [...selectedProject.characters, char] };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const updateCharacter = (id: string, field: keyof Character, value: string) => {
    if (!selectedProject) return;
    const updated = { ...selectedProject, characters: selectedProject.characters.map(c => c.id === id ? { ...c, [field]: value } : c) };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const deleteCharacter = (id: string) => {
    if (!selectedProject) return;
    const updated = { ...selectedProject, characters: selectedProject.characters.filter(c => c.id !== id) };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  /* ── Episode CRUD ── */
  const addEpisode = () => {
    if (!selectedProject) return;
    const ep: Episode = { id: `ep_${Date.now()}`, title: `Episode ${selectedProject.episodes.length + 1}`, scenes: [] };
    const updated = { ...selectedProject, episodes: [...selectedProject.episodes, ep] };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p)); setSelectedEpisode(ep.id);
  };

  /* ── Scene CRUD ── */
  const addScene = () => {
    if (!selectedProject || !selectedEpisode) return;
    const ep = selectedProject.episodes.find(e => e.id === selectedEpisode);
    const scene: Scene = { id: `scene_${Date.now()}`, title: `Scene ${(ep?.scenes.length ?? 0) + 1}`, description: '', characters: [], camera: 'static shot', duration: 3, background: '', mood: 'Calm and peaceful', dialogue: '', seed: Math.floor(Math.random() * 9999999999), status: 'pending', progress: 0 };
    const updated = { ...selectedProject, episodes: selectedProject.episodes.map(e => e.id === selectedEpisode ? { ...e, scenes: [...e.scenes, scene] } : e) };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const updateSceneField = (sceneId: string, field: keyof Scene, value: string | number | string[]) => {
    if (!selectedProject || !selectedEpisode) return;
    const updated = { ...selectedProject, episodes: selectedProject.episodes.map(e => e.id === selectedEpisode ? { ...e, scenes: e.scenes.map(s => s.id === sceneId ? { ...s, [field]: value } : s) } : e) };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const deleteScene = (sceneId: string) => {
    if (!selectedProject || !selectedEpisode) return;
    const updated = { ...selectedProject, episodes: selectedProject.episodes.map(e => e.id === selectedEpisode ? { ...e, scenes: e.scenes.filter(s => s.id !== sceneId) } : e) };
    setSelectedProject(updated); setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  /* ── Stats ── */
  const stats = {
    projects: projects.length,
    episodes: projects.reduce((a, p) => a + p.episodes.length, 0),
    scenesDone: projects.reduce((a, p) => a + p.episodes.reduce((b, e) => b + e.scenes.filter(s => s.status === 'done').length, 0), 0),
    scenesTotal: projects.reduce((a, p) => a + p.episodes.reduce((b, e) => b + e.scenes.length, 0), 0),
    characters: projects.reduce((a, p) => a + p.characters.length, 0),
    duration: projects.reduce((a, p) => a + p.episodes.reduce((b, e) => b + e.scenes.reduce((c, s) => c + s.duration, 0), 0), 0),
  };

  /* ═══════════════════════════ RENDER ═══════════════════════════ */

  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-purple-900 via-indigo-900 to-pink-900 p-8 border border-purple-700/40">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, #7c3aed 0%, transparent 50%), radial-gradient(circle at 80% 20%, #ec4899 0%, transparent 40%)' }} />
        <div className="relative">
          <div className="flex items-center gap-3 mb-3">
            <span className="text-4xl">🎌</span>
            <h1 className="text-3xl font-bold text-white tracking-tight">LTX-2 Anime Agent</h1>
          </div>
          <p className="text-purple-200 text-lg mb-1">AI-Powered Local Anime Video Creation Studio</p>
          <p className="text-purple-300/70 text-sm">Create anime series with character consistency using ComfyUI + Ollama</p>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
        {[
          { label: 'Projects', value: stats.projects, icon: '📁', col: 'from-blue-900/50 to-blue-800/30 border-blue-700/30' },
          { label: 'Episodes', value: stats.episodes, icon: '📺', col: 'from-purple-900/50 to-purple-800/30 border-purple-700/30' },
          { label: 'Scenes Done', value: `${stats.scenesDone}/${stats.scenesTotal}`, icon: '🎬', col: 'from-green-900/50 to-green-800/30 border-green-700/30' },
          { label: 'Characters', value: stats.characters, icon: '🎭', col: 'from-pink-900/50 to-pink-800/30 border-pink-700/30' },
          { label: 'Duration', value: `${stats.duration}s`, icon: '⏱️', col: 'from-yellow-900/50 to-yellow-800/30 border-yellow-700/30' },
          { label: 'Est. Size', value: `${(stats.duration * 0.5).toFixed(0)}MB`, icon: '💾', col: 'from-cyan-900/50 to-cyan-800/30 border-cyan-700/30' },
        ].map(s => (
          <div key={s.label} className={`bg-gradient-to-br ${s.col} border rounded-xl p-3 text-center`}>
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className="text-xl font-bold text-white">{s.value}</div>
            <div className="text-xs text-gray-400">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Connections */}
      <div className="grid sm:grid-cols-2 gap-4">
        {[
          { key: 'comfyui' as const, name: 'ComfyUI', url: connections.comfyuiUrl, icon: '🎨' },
          { key: 'ollama' as const, name: 'Ollama', url: connections.ollamaUrl, icon: '🦙' },
        ].map(svc => (
          <div key={svc.key} className="bg-gray-800/60 border border-gray-700/50 rounded-xl p-4">
            <div className="flex items-center gap-3 mb-3">
              <span className="text-2xl">{svc.icon}</span>
              <div>
                <div className="flex items-center gap-2">
                  <StatusDot status={connections[svc.key]} />
                  <span className="font-semibold text-white">{svc.name}</span>
                  <Badge color={connections[svc.key] === 'connected' ? 'green' : connections[svc.key] === 'checking' ? 'yellow' : 'red'}>
                    {connections[svc.key]}
                  </Badge>
                </div>
                <div className="text-xs text-gray-500 mt-0.5">{svc.url}</div>
              </div>
            </div>
            {svc.key === 'comfyui' && connections.comfyui === 'connected' && (
              <div className="space-y-1 text-sm text-gray-300">
                <div>🎮 {connections.gpu} ({connections.gpuMemory})</div>
                <div className="flex gap-3 flex-wrap">
                  <span>📦 Models: {connections.comfyuiModels.length || 'None'}</span>
                  <span>📦 VAEs: {connections.comfyuiVAEs.length || 'None'}</span>
                </div>
                <div className="flex gap-3 flex-wrap text-xs">
                  <span className={connections.hasVHS ? 'text-green-400' : 'text-red-400'}>VHS: {connections.hasVHS ? '✓' : '✗'}</span>
                  <span className={connections.hasGGUF ? 'text-green-400' : 'text-yellow-400'}>GGUF: {connections.hasGGUF ? '✓' : 'N/A'}</span>
                </div>
              </div>
            )}
            {svc.key === 'ollama' && connections.ollama === 'connected' && (
              <div className="space-y-1 text-sm text-gray-300">
                <div>🤖 {connections.ollamaModels.length} model(s)</div>
                {connections.ollamaModels.length > 0 && <div className="text-xs text-gray-400">{connections.ollamaModels.slice(0, 3).join(', ')}</div>}
                {connections.ollamaModels.length === 0 && <div className="text-xs text-yellow-400 font-mono">Run: ollama pull llama3.2</div>}
              </div>
            )}
            {connections[svc.key] === 'disconnected' && (
              <div className="text-sm text-red-400">Not connected. {svc.key === 'comfyui' ? 'Start ComfyUI on port 8188.' : 'Run: ollama serve'}</div>
            )}
          </div>
        ))}
      </div>

      {/* Quick actions */}
      <div className="flex flex-wrap gap-3">
        <button onClick={checkConnections} className="flex items-center gap-2 px-4 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-medium transition-colors">
          🔄 Reconnect
        </button>
        <button onClick={() => setActiveTab('create')} className="flex items-center gap-2 px-4 py-2.5 bg-purple-600 hover:bg-purple-500 text-white rounded-xl font-medium transition-colors">
          ➕ New Project
        </button>
        <button onClick={() => setActiveTab('guide')} className="flex items-center gap-2 px-4 py-2.5 bg-gray-700 hover:bg-gray-600 text-white rounded-xl font-medium transition-colors">
          📖 Setup Guide
        </button>
        <button onClick={() => setShowLog(v => !v)} className="flex items-center gap-2 px-4 py-2.5 bg-gray-700 hover:bg-gray-600 text-white rounded-xl font-medium transition-colors">
          📋 {showLog ? 'Hide' : 'Show'} Log
        </button>
      </div>

      {/* Log */}
      {showLog && (
        <div className="bg-black/60 border border-gray-700/50 rounded-xl p-4 max-h-48 overflow-y-auto font-mono text-xs text-green-300 space-y-0.5">
          {logs.length === 0 ? <span className="text-gray-500">No logs yet.</span> : logs.map((l, i) => <div key={i}>{l}</div>)}
        </div>
      )}

      {/* Projects list */}
      <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-700/50">
          <h2 className="font-semibold text-white text-lg">📁 Your Projects</h2>
          <button onClick={() => setActiveTab('create')} className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-sm transition-colors">+ New</button>
        </div>
        {projects.length === 0 ? (
          <div className="text-center py-16 text-gray-500">
            <div className="text-5xl mb-4">🎬</div>
            <p className="text-lg mb-1">No projects yet</p>
            <p className="text-sm">Create your first anime project to get started!</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-700/40">
            {projects.map(project => {
              const scenes = project.episodes.reduce((a, e) => a + e.scenes.length, 0);
              const done = project.episodes.reduce((a, e) => a + e.scenes.filter(s => s.status === 'done').length, 0);
              const dur = project.episodes.reduce((a, e) => a + e.scenes.reduce((b, s) => b + s.duration, 0), 0);
              return (
                <div key={project.id} className="flex items-center gap-4 px-5 py-4 hover:bg-gray-700/30 transition-colors cursor-pointer group"
                  onClick={() => { setSelectedProject(project); setSelectedEpisode(null); setActiveTab('project'); }}>
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-purple-600 to-pink-600 flex items-center justify-center text-lg font-bold text-white shrink-0">
                    {project.name[0]}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-semibold text-white">{project.name}</span>
                      <Badge color="purple">{project.style}</Badge>
                    </div>
                    <div className="text-sm text-gray-400 truncate">{project.description}</div>
                    <div className="flex gap-3 text-xs text-gray-500 mt-1 flex-wrap">
                      <span>📺 {project.episodes.length} eps</span>
                      <span>🎬 {done}/{scenes} scenes</span>
                      <span>🎭 {project.characters.length} chars</span>
                      <span>⏱️ {dur}s</span>
                    </div>
                    {scenes > 0 && (
                      <div className="mt-2 h-1.5 bg-gray-700 rounded-full overflow-hidden w-48">
                        <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 rounded-full transition-all" style={{ width: `${(done / scenes) * 100}%` }} />
                      </div>
                    )}
                  </div>
                  <button onClick={e => { e.stopPropagation(); deleteProject(project.id); }} className="opacity-0 group-hover:opacity-100 px-3 py-1.5 bg-red-900/50 hover:bg-red-800 text-red-300 rounded-lg text-sm transition-all">
                    🗑️
                  </button>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );

  /* ── Create Project ── */
  const CreateProject = () => {
    const [name, setName] = useState('');
    const [desc, setDesc] = useState('');
    const [style, setStyle] = useState('Anime Classic');
    return (
      <div className="max-w-xl mx-auto space-y-5">
        <h2 className="text-2xl font-bold text-white">➕ New Project</h2>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">Project Name</label>
          <input value={name} onChange={e => setName(e.target.value)} placeholder="My Anime Series"
            className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors" />
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">Story Description</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={4} placeholder="A young hero discovers their destiny in a world of magic and adventure..."
            className="w-full bg-gray-800 border border-gray-700 rounded-xl px-4 py-3 text-white placeholder-gray-500 focus:outline-none focus:border-purple-500 transition-colors resize-none" />
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">Anime Style</label>
          <div className="grid grid-cols-2 gap-2">
            {Object.keys(STYLE_PRESETS).map(s => (
              <button key={s} onClick={() => setStyle(s)}
                className={`px-3 py-2.5 rounded-xl text-sm font-medium border transition-all ${style === s ? 'bg-purple-600 border-purple-500 text-white' : 'bg-gray-800 border-gray-700 text-gray-300 hover:border-gray-500'}`}>
                {s}
              </button>
            ))}
          </div>
        </div>
        <div className="flex gap-3">
          <button onClick={() => setActiveTab('dashboard')} className="flex-1 px-4 py-3 bg-gray-700 hover:bg-gray-600 text-white rounded-xl transition-colors">
            Cancel
          </button>
          <button onClick={() => { if (name.trim()) createProject(name.trim(), desc, style); }}
            disabled={!name.trim()}
            className="flex-1 px-4 py-3 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl font-semibold transition-all">
            Create Project 🚀
          </button>
        </div>
      </div>
    );
  };

  /* ── Project View ── */
  const renderProject = () => {
    if (!selectedProject) return (
      <div className="text-center py-20 text-gray-500">
        <div className="text-5xl mb-4">📁</div>
        <p>No project selected. <button onClick={() => setActiveTab('dashboard')} className="text-purple-400 hover:underline">Go to Dashboard</button></p>
      </div>
    );

    const currentEpisode = selectedProject.episodes.find(e => e.id === selectedEpisode);

    return (
      <div className="space-y-5">
        {/* Project Header */}
        <div className="flex items-start gap-4 flex-wrap">
          <div className="flex-1">
            <div className="flex items-center gap-3 flex-wrap mb-1">
              <h2 className="text-2xl font-bold text-white">{selectedProject.name}</h2>
              <Badge color="purple">{selectedProject.style}</Badge>
            </div>
            <p className="text-gray-400 text-sm">{selectedProject.description}</p>
          </div>
          <button onClick={() => setActiveTab('dashboard')} className="px-3 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-xl text-sm transition-colors">← Back</button>
        </div>

        {/* Characters */}
        <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-gray-700/50">
            <h3 className="font-semibold text-white">🎭 Characters ({selectedProject.characters.length})</h3>
            <div className="flex gap-2">
              {connections.ollama === 'connected' && (
                <button onClick={aiGenerateCharacters} disabled={aiGenerating}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-sm transition-colors flex items-center gap-1.5">
                  {aiGenerating ? '⟳ Generating...' : '🤖 AI Generate'}
                </button>
              )}
              <button onClick={addCharacter} className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-sm transition-colors">+ Add</button>
            </div>
          </div>
          {selectedProject.characters.length === 0 ? (
            <div className="text-center py-8 text-gray-500 text-sm">No characters yet. Add manually or use AI Generate.</div>
          ) : (
            <div className="divide-y divide-gray-700/40">
              {selectedProject.characters.map(char => (
                <div key={char.id} className="px-5 py-3 flex items-start gap-3 group">
                  <div className="w-8 h-8 rounded-full shrink-0 mt-1" style={{ backgroundColor: char.color }} />
                  <div className="flex-1 grid sm:grid-cols-2 gap-2">
                    <div>
                      <input value={char.name} onChange={e => updateCharacter(char.id, 'name', e.target.value)}
                        className="w-full bg-gray-700/60 rounded-lg px-3 py-1.5 text-white text-sm font-semibold border border-transparent focus:border-purple-500 focus:outline-none" />
                    </div>
                    <div>
                      <select value={char.role} onChange={e => updateCharacter(char.id, 'role', e.target.value)}
                        className="w-full bg-gray-700/60 rounded-lg px-3 py-1.5 text-gray-300 text-sm border border-transparent focus:border-purple-500 focus:outline-none">
                        {(['protagonist', 'antagonist', 'supporting', 'minor'] as const).map(r => <option key={r} value={r}>{r}</option>)}
                      </select>
                    </div>
                    <div className="sm:col-span-2">
                      <textarea value={char.appearance} onChange={e => updateCharacter(char.id, 'appearance', e.target.value)}
                        placeholder="Appearance description..." rows={2}
                        className="w-full bg-gray-700/60 rounded-lg px-3 py-1.5 text-gray-300 text-sm border border-transparent focus:border-purple-500 focus:outline-none resize-none" />
                    </div>
                    <div className="sm:col-span-2">
                      <input value={char.consistentPrompt} onChange={e => updateCharacter(char.id, 'consistentPrompt', e.target.value)}
                        placeholder="Consistent rendering prompt (e.g. blue-haired girl with red eyes)..."
                        className="w-full bg-gray-700/60 rounded-lg px-3 py-1.5 text-gray-400 text-xs border border-transparent focus:border-purple-500 focus:outline-none" />
                    </div>
                  </div>
                  <button onClick={() => deleteCharacter(char.id)} className="opacity-0 group-hover:opacity-100 p-1.5 text-red-400 hover:text-red-300 transition-all text-sm">✕</button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Episodes */}
        <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl overflow-hidden">
          <div className="flex items-center justify-between px-5 py-3 border-b border-gray-700/50">
            <h3 className="font-semibold text-white">📺 Episodes ({selectedProject.episodes.length})</h3>
            <div className="flex gap-2">
              {connections.ollama === 'connected' && selectedProject.characters.length > 0 && (
                <button onClick={aiGenerateStory} disabled={aiGenerating}
                  className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-sm transition-colors">
                  {aiGenerating ? '⟳ AI Writing...' : '🤖 AI Story'}
                </button>
              )}
              <button onClick={addEpisode} className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-sm transition-colors">+ Episode</button>
            </div>
          </div>
          {selectedProject.episodes.length === 0 ? (
            <div className="text-center py-8 text-gray-500 text-sm">No episodes yet. Use AI Story or add manually.</div>
          ) : (
            <div className="flex gap-2 p-3 flex-wrap border-b border-gray-700/50">
              {selectedProject.episodes.map(ep => (
                <button key={ep.id} onClick={() => setSelectedEpisode(ep.id)}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${selectedEpisode === ep.id ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>
                  {ep.title}
                  <span className="ml-2 text-xs opacity-70">{ep.scenes.length} scenes</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Scenes */}
        {currentEpisode && (
          <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-5 py-3 border-b border-gray-700/50">
              <h3 className="font-semibold text-white">🎬 {currentEpisode.title} — Scenes ({currentEpisode.scenes.length})</h3>
              <div className="flex gap-2">
                {connections.comfyui === 'connected' && (
                  <button onClick={generateEpisode} disabled={generating || currentEpisode.scenes.length === 0}
                    className="px-3 py-1.5 bg-green-700 hover:bg-green-600 disabled:opacity-50 text-white rounded-lg text-sm transition-colors flex items-center gap-1.5">
                    {generating ? '⟳ Generating...' : '▶ Generate All'}
                  </button>
                )}
                <button onClick={downloadBatchScript} disabled={currentEpisode.scenes.length === 0}
                  className="px-3 py-1.5 bg-gray-700 hover:bg-gray-600 disabled:opacity-50 text-white rounded-lg text-sm transition-colors">
                  📥 Batch Script
                </button>
                <button onClick={addScene} className="px-3 py-1.5 bg-purple-600 hover:bg-purple-500 text-white rounded-lg text-sm transition-colors">+ Scene</button>
              </div>
            </div>
            {currentEpisode.scenes.length === 0 ? (
              <div className="text-center py-8 text-gray-500 text-sm">No scenes. Add manually or use AI Story to generate.</div>
            ) : (
              <div className="divide-y divide-gray-700/40">
                {currentEpisode.scenes.map((scene) => (
                  <SceneCard key={scene.id} scene={scene}
                    project={selectedProject}
                    onUpdate={(field, val) => updateSceneField(scene.id, field, val)}
                    onDelete={() => deleteScene(scene.id)}
                    onDownload={() => downloadWorkflow(scene)}
                    onQueue={() => {
                      const epIdx = selectedProject.episodes.findIndex(e => e.id === selectedEpisode);
                      const scIdx = currentEpisode.scenes.findIndex(s => s.id === scene.id);
                      queueScene(scene, epIdx, scIdx);
                    }}
                    canQueue={connections.comfyui === 'connected'}
                  />
                ))}
              </div>
            )}
          </div>
        )}
      </div>
    );
  };

  /* ── Settings ── */
  const renderSettings = () => (
    <div className="max-w-xl mx-auto space-y-5">
      <h2 className="text-2xl font-bold text-white">⚙️ Settings</h2>

      {/* URL Config */}
      <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl p-5 space-y-4">
        <h3 className="font-semibold text-white">🔗 Connection URLs</h3>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">ComfyUI URL</label>
          <input value={connections.comfyuiUrl} onChange={e => setConnections(p => ({ ...p, comfyuiUrl: e.target.value }))}
            className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500" />
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">Ollama URL</label>
          <input value={connections.ollamaUrl} onChange={e => setConnections(p => ({ ...p, ollamaUrl: e.target.value }))}
            className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500" />
        </div>
        <button onClick={checkConnections} className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-medium transition-colors">
          🔄 Test Connections
        </button>
      </div>

      {/* Generation Settings */}
      <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl p-5 space-y-4">
        <h3 className="font-semibold text-white">🎬 Generation Settings</h3>
        <div className="grid grid-cols-2 gap-4">
          {[
            { label: 'Width', key: 'width' as const, type: 'number', min: 256, max: 1280, step: 64 },
            { label: 'Height', key: 'height' as const, type: 'number', min: 256, max: 720, step: 64 },
            { label: 'FPS', key: 'fps' as const, type: 'number', min: 8, max: 30, step: 1 },
            { label: 'Steps', key: 'steps' as const, type: 'number', min: 4, max: 50, step: 1 },
            { label: 'CFG Scale', key: 'cfg' as const, type: 'number', min: 1, max: 10, step: 0.5 },
          ].map(f => (
            <div key={f.key}>
              <label className="block text-sm text-gray-400 mb-1.5">{f.label}</label>
              <input type={f.type} value={settings[f.key]} min={f.min} max={f.max} step={f.step}
                onChange={e => setSettings(p => ({ ...p, [f.key]: parseFloat(e.target.value) }))}
                className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500" />
            </div>
          ))}
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Sampler</label>
            <select value={settings.sampler} onChange={e => setSettings(p => ({ ...p, sampler: e.target.value }))}
              className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500">
              {['euler', 'euler_ancestral', 'heun', 'dpm_2', 'dpm_2_ancestral', 'lms', 'dpm_fast', 'dpm_adaptive', 'dpmpp_2s_ancestral', 'dpmpp_sde', 'dpmpp_2m', 'ddim', 'uni_pc'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1.5">Scheduler</label>
            <select value={settings.scheduler} onChange={e => setSettings(p => ({ ...p, scheduler: e.target.value }))}
              className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500">
              {['normal', 'karras', 'exponential', 'simple', 'ddim_uniform'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">Model File</label>
          <input value={settings.modelFile} onChange={e => setSettings(p => ({ ...p, modelFile: e.target.value }))}
            placeholder="ltx-video-2b-Q4_K_M.gguf"
            className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500" />
          {connections.comfyuiModels.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {connections.comfyuiModels.map(m => (
                <button key={m} onClick={() => setSettings(p => ({ ...p, modelFile: m }))}
                  className={`text-xs px-2 py-1 rounded-lg transition-colors ${settings.modelFile === m ? 'bg-purple-600 text-white' : 'bg-gray-600 text-gray-300 hover:bg-gray-500'}`}>
                  {m}
                </button>
              ))}
            </div>
          )}
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1.5">VAE File</label>
          <input value={settings.vaeFile} onChange={e => setSettings(p => ({ ...p, vaeFile: e.target.value }))}
            placeholder="ltx-video-2b.safetensors"
            className="w-full bg-gray-700 rounded-xl px-4 py-2.5 text-white text-sm border border-gray-600 focus:outline-none focus:border-purple-500" />
          {connections.comfyuiVAEs.length > 0 && (
            <div className="mt-2 flex flex-wrap gap-1">
              {connections.comfyuiVAEs.map(v => (
                <button key={v} onClick={() => setSettings(p => ({ ...p, vaeFile: v }))}
                  className={`text-xs px-2 py-1 rounded-lg transition-colors ${settings.vaeFile === v ? 'bg-purple-600 text-white' : 'bg-gray-600 text-gray-300 hover:bg-gray-500'}`}>
                  {v}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Resolution presets */}
      <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl p-5">
        <h3 className="font-semibold text-white mb-3">📐 Resolution Presets</h3>
        <div className="flex flex-wrap gap-2">
          {[
            { label: '512×384 (6GB)', w: 512, h: 384 },
            { label: '640×480', w: 640, h: 480 },
            { label: '768×512', w: 768, h: 512 },
            { label: '720p (1280×720)', w: 1280, h: 720 },
          ].map(p => (
            <button key={p.label} onClick={() => setSettings(prev => ({ ...prev, width: p.w, height: p.h }))}
              className={`px-3 py-2 rounded-xl text-sm transition-colors ${settings.width === p.w && settings.height === p.h ? 'bg-purple-600 text-white' : 'bg-gray-700 hover:bg-gray-600 text-gray-300'}`}>
              {p.label}
            </button>
          ))}
        </div>
        <p className="text-xs text-gray-500 mt-2">💡 GTX 1660 Ti (6GB): Use 512×384 or lower for best performance</p>
      </div>
    </div>
  );

  /* ── Setup Guide ── */
  const renderGuide = () => (
    <div className="space-y-4">
      <div className="flex items-center gap-3 mb-2">
        <h2 className="text-2xl font-bold text-white">📖 Setup Guide</h2>
        <Badge color="blue">GTX 1660 Ti Optimized</Badge>
      </div>
      <p className="text-gray-400 text-sm">Follow these steps to set up your local AI anime video generation pipeline.</p>
      {SETUP_GUIDE.map((step, i) => (
        <div key={i} className="bg-gray-800/60 border border-gray-700/50 rounded-xl overflow-hidden">
          <button onClick={() => setExpandedGuide(expandedGuide === i ? null : i)}
            className="w-full flex items-center gap-4 px-5 py-4 hover:bg-gray-700/30 transition-colors text-left">
            <div className="w-10 h-10 rounded-xl bg-gray-700 flex items-center justify-center text-xl shrink-0">{step.icon}</div>
            <div className="flex-1">
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-purple-400">Step {i + 1}</span>
              </div>
              <div className="font-semibold text-white">{step.title}</div>
              <div className="text-sm text-gray-400">{step.description}</div>
            </div>
            <span className="text-gray-500 text-lg">{expandedGuide === i ? '▲' : '▼'}</span>
          </button>
          {expandedGuide === i && (
            <div className="px-5 pb-5 border-t border-gray-700/50 pt-4">
              <div className="bg-black/40 rounded-xl p-4 font-mono text-sm space-y-1">
                {step.steps.map((cmd, j) => (
                  <div key={j}>
                    {cmd === '' ? <div className="h-2" /> : (
                      <div className="flex items-start gap-2 group">
                        <span className={cmd.startsWith('#') ? 'text-gray-500' : 'text-green-300 flex-1'}>{cmd}</span>
                        {!cmd.startsWith('#') && cmd.length > 0 && (
                          <span className="opacity-0 group-hover:opacity-100 transition-opacity shrink-0">
                            <CopyButton text={cmd} />
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
              {step.tip && (
                <div className="mt-3 flex items-start gap-2 text-sm text-yellow-300/80">
                  <span>💡</span>
                  <span>{step.tip}</span>
                </div>
              )}
            </div>
          )}
        </div>
      ))}
    </div>
  );

  /* ── Troubleshooting ── */
  const renderTroubleshoot = () => (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold text-white">🔧 Troubleshooting</h2>
      <p className="text-gray-400 text-sm">Common issues and their solutions.</p>
      <div className="space-y-3">
        {TROUBLESHOOTING.map((item, i) => (
          <div key={i} className="bg-gray-800/60 border border-gray-700/50 rounded-xl p-5">
            <div className="flex items-start gap-3">
              <span className="text-red-400 text-lg shrink-0">⚠️</span>
              <div>
                <div className="font-semibold text-white mb-1">{item.issue}</div>
                <div className="text-sm text-gray-300">{item.fix}</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Log viewer */}
      <div className="bg-gray-800/60 border border-gray-700/50 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-gray-700/50">
          <h3 className="font-semibold text-white">📋 Activity Log</h3>
          <button onClick={() => setLogs([])} className="text-xs text-gray-500 hover:text-gray-300">Clear</button>
        </div>
        <div className="p-4 bg-black/40 max-h-64 overflow-y-auto font-mono text-xs text-green-300 space-y-0.5">
          {logs.length === 0 ? <span className="text-gray-600">No logs yet. Activity will appear here.</span> : logs.map((l, i) => <div key={i}>{l}</div>)}
        </div>
      </div>
    </div>
  );

  /* ─── Navigation ─── */
  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: '🏠' },
    { id: 'create', label: 'New Project', icon: '➕' },
    { id: 'project', label: 'Project', icon: '📁', show: !!selectedProject },
    { id: 'settings', label: 'Settings', icon: '⚙️' },
    { id: 'guide', label: 'Setup Guide', icon: '📖' },
    { id: 'troubleshoot', label: 'Troubleshoot', icon: '🔧' },
  ] as const;

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      {/* Sidebar + Main */}
      <div className="flex min-h-screen">
        {/* Sidebar */}
        <aside className="w-56 shrink-0 bg-gray-900 border-r border-gray-800 flex flex-col">
          <div className="p-4 border-b border-gray-800">
            <div className="flex items-center gap-2.5">
              <span className="text-2xl">🎌</span>
              <div>
                <div className="font-bold text-white text-sm leading-tight">LTX-2 Anime</div>
                <div className="text-xs text-gray-500">AI Video Agent</div>
              </div>
            </div>
          </div>

          {/* Connection indicators */}
          <div className="px-4 py-3 border-b border-gray-800 space-y-1.5">
            <div className="flex items-center gap-2 text-xs">
              <StatusDot status={connections.comfyui} />
              <span className="text-gray-400">ComfyUI</span>
            </div>
            <div className="flex items-center gap-2 text-xs">
              <StatusDot status={connections.ollama} />
              <span className="text-gray-400">Ollama</span>
            </div>
          </div>

          <nav className="flex-1 py-3">
            {tabs.filter(t => !('show' in t) || t.show).map(tab => (
              <button key={tab.id} onClick={() => setActiveTab(tab.id as typeof activeTab)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors ${activeTab === tab.id ? 'bg-purple-600/20 text-purple-300 border-r-2 border-purple-500' : 'text-gray-400 hover:text-white hover:bg-gray-800'}`}>
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>

          {/* Log button */}
          <div className="p-4 border-t border-gray-800">
            <button onClick={() => setShowLog(v => !v)}
              className="w-full flex items-center gap-2 px-3 py-2 bg-gray-800 hover:bg-gray-700 rounded-xl text-xs text-gray-400 transition-colors">
              <span>📋</span>
              <span>Activity Log</span>
              {logs.length > 0 && <span className="ml-auto bg-purple-600 text-white text-xs rounded-full px-1.5">{Math.min(logs.length, 99)}</span>}
            </button>
          </div>
        </aside>

        {/* Main content */}
        <main className="flex-1 flex flex-col min-w-0">
          {/* Top bar */}
          <header className="bg-gray-900/80 border-b border-gray-800 px-6 py-3 flex items-center justify-between sticky top-0 z-10 backdrop-blur-sm">
            <div className="text-sm text-gray-400">
              {activeTab === 'project' && selectedProject ? (
                <span>📁 {selectedProject.name}</span>
              ) : (
                <span>{tabs.find(t => t.id === activeTab)?.icon} {tabs.find(t => t.id === activeTab)?.label}</span>
              )}
            </div>
            <div className="flex items-center gap-3">
              {aiGenerating && <span className="text-xs text-purple-300 animate-pulse">🤖 AI generating...</span>}
              {generating && <span className="text-xs text-green-300 animate-pulse">🎬 Rendering...</span>}
              <button onClick={checkConnections} className="text-xs px-3 py-1.5 bg-gray-800 hover:bg-gray-700 text-gray-400 rounded-lg transition-colors">
                🔄 Reconnect
              </button>
            </div>
          </header>

          {/* Page */}
          <div className="flex-1 p-6 overflow-y-auto">
            {activeTab === 'dashboard' && renderDashboard()}
            {activeTab === 'create' && <CreateProject />}
            {activeTab === 'project' && renderProject()}
            {activeTab === 'settings' && renderSettings()}
            {activeTab === 'guide' && renderGuide()}
            {activeTab === 'troubleshoot' && renderTroubleshoot()}
          </div>
        </main>
      </div>

      {/* Floating Log Drawer */}
      {showLog && (
        <div className="fixed bottom-4 right-4 w-96 bg-gray-900 border border-gray-700 rounded-2xl shadow-2xl overflow-hidden z-50">
          <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700">
            <span className="font-semibold text-white text-sm">📋 Activity Log</span>
            <div className="flex gap-2">
              <button onClick={() => setLogs([])} className="text-xs text-gray-500 hover:text-gray-300">Clear</button>
              <button onClick={() => setShowLog(false)} className="text-gray-500 hover:text-white">✕</button>
            </div>
          </div>
          <div className="max-h-64 overflow-y-auto p-3 font-mono text-xs text-green-300 space-y-0.5 bg-black/40">
            {logs.length === 0 ? <span className="text-gray-600">No activity yet.</span> : logs.map((l, i) => <div key={i}>{l}</div>)}
          </div>
        </div>
      )}
    </div>
  );
}

/* ─────────────────── Scene Card Component ─────────────────── */
function SceneCard({
  scene, project, onUpdate, onDelete, onDownload, onQueue, canQueue,
}: {
  scene: Scene;
  project: Project;
  onUpdate: (field: keyof Scene, value: string | number | string[]) => void;
  onDelete: () => void;
  onDownload: () => void;
  onQueue: () => void;
  canQueue: boolean;
}) {
  const [expanded, setExpanded] = useState(false);

  return (
    <div className="border-b border-gray-700/40 last:border-0">
      <div className="px-5 py-3 flex items-center gap-3 hover:bg-gray-700/20 transition-colors group">
        {/* Drag handle / index visual */}
        <div className="w-6 text-center text-gray-600 text-xs shrink-0">≡</div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <input value={scene.title} onChange={e => onUpdate('title', e.target.value)}
              className="font-semibold text-white bg-transparent border-b border-transparent hover:border-gray-600 focus:border-purple-500 focus:outline-none text-sm" />
            <SceneStatusBadge status={scene.status} />
            <Badge color="gray">{scene.duration}s</Badge>
            <Badge color="gray">{scene.camera}</Badge>
          </div>
          <div className="text-xs text-gray-500 truncate mt-0.5">{scene.description || 'No description'}</div>
          {scene.status === 'generating' && (
            <div className="mt-1.5 h-1 bg-gray-700 rounded-full overflow-hidden w-32">
              <div className="h-full bg-gradient-to-r from-purple-500 to-pink-500 animate-pulse rounded-full transition-all" style={{ width: `${scene.progress}%` }} />
            </div>
          )}
          {scene.status === 'error' && <div className="text-xs text-red-400 mt-0.5">⚠️ {scene.error}</div>}
        </div>
        <div className="flex items-center gap-1.5 shrink-0">
          {canQueue && (
            <button onClick={onQueue} disabled={scene.status === 'generating'}
              className="opacity-0 group-hover:opacity-100 px-2.5 py-1.5 bg-green-700/70 hover:bg-green-600 disabled:opacity-50 text-white rounded-lg text-xs transition-all">
              ▶
            </button>
          )}
          <button onClick={onDownload}
            className="opacity-0 group-hover:opacity-100 px-2.5 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg text-xs transition-all">
            📥
          </button>
          <button onClick={() => setExpanded(v => !v)}
            className="px-2.5 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg text-xs transition-colors">
            {expanded ? '▲' : '▼'}
          </button>
          <button onClick={onDelete}
            className="opacity-0 group-hover:opacity-100 px-2.5 py-1.5 bg-red-900/50 hover:bg-red-800 text-red-300 rounded-lg text-xs transition-all">
            ✕
          </button>
        </div>
      </div>

      {expanded && (
        <div className="px-5 pb-4 pt-2 bg-gray-900/40 border-t border-gray-700/30 grid sm:grid-cols-2 gap-3">
          <div className="sm:col-span-2">
            <label className="block text-xs text-gray-500 mb-1">Scene Description</label>
            <textarea value={scene.description} onChange={e => onUpdate('description', e.target.value)} rows={2}
              placeholder="Describe what happens in this scene..."
              className="w-full bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500 resize-none" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Characters</label>
            <div className="flex flex-wrap gap-1.5">
              {project.characters.map(c => (
                <button key={c.id} onClick={() => {
                  const sel = scene.characters.includes(c.id) ? scene.characters.filter(id => id !== c.id) : [...scene.characters, c.id];
                  onUpdate('characters', sel);
                }}
                  className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs transition-all border ${scene.characters.includes(c.id) ? 'border-transparent text-white' : 'bg-gray-800 border-gray-700 text-gray-400 hover:border-gray-500'}`}
                  style={scene.characters.includes(c.id) ? { backgroundColor: c.color + '40', borderColor: c.color } : {}}>
                  <span className="w-2 h-2 rounded-full" style={{ backgroundColor: c.color }} />
                  {c.name}
                </button>
              ))}
              {project.characters.length === 0 && <span className="text-xs text-gray-600">No characters in project</span>}
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Duration (seconds)</label>
            <input type="number" min={1} max={30} value={scene.duration} onChange={e => onUpdate('duration', parseInt(e.target.value) || 3)}
              className="w-full bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Camera Movement</label>
            <select value={scene.camera} onChange={e => onUpdate('camera', e.target.value)}
              className="w-full bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500">
              {CAMERA_MOVEMENTS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Mood</label>
            <select value={scene.mood} onChange={e => onUpdate('mood', e.target.value)}
              className="w-full bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500">
              {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs text-gray-500 mb-1">Background / Setting</label>
            <input value={scene.background} onChange={e => onUpdate('background', e.target.value)}
              placeholder="e.g. rooftop at sunset with city skyline..."
              className="w-full bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500" />
          </div>
          <div className="sm:col-span-2">
            <label className="block text-xs text-gray-500 mb-1">Dialogue (or leave blank)</label>
            <input value={scene.dialogue} onChange={e => onUpdate('dialogue', e.target.value)}
              placeholder='e.g. "I will never give up!"'
              className="w-full bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Seed</label>
            <div className="flex gap-2">
              <input type="number" value={scene.seed || 0} onChange={e => onUpdate('seed', parseInt(e.target.value) || 0)}
                className="flex-1 bg-gray-800 rounded-xl px-3 py-2 text-sm text-white border border-gray-700 focus:outline-none focus:border-purple-500" />
              <button onClick={() => onUpdate('seed', Math.floor(Math.random() * 9999999999))}
                className="px-3 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-xl text-xs transition-colors">🎲</button>
            </div>
          </div>
          <div className="flex items-end">
            <button onClick={onDownload}
              className="w-full px-3 py-2 bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-xl text-sm transition-colors">
              📥 Download Workflow JSON
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
