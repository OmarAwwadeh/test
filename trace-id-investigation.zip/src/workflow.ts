import { Scene, WorkflowSettings, Project } from './types';
import { STYLE_PRESETS } from './constants';

export function generateWorkflow(
  scene: Scene,
  settings: WorkflowSettings,
  project: Project,
  useVHS: boolean = true
): Record<string, unknown> {
  const chars = scene.characters
    .map((id) => project.characters.find((c) => c.id === id))
    .filter(Boolean);

  const charDescriptions = chars.length > 0
    ? chars.map((c) => `${c!.name}: ${c!.appearance}. ${c!.consistentPrompt}`).join('. ')
    : '';

  const style = STYLE_PRESETS[project.style] || STYLE_PRESETS['Anime Classic'];

  const positivePromptParts = [
    style,
    scene.description,
    charDescriptions ? `Characters: ${charDescriptions}` : '',
    scene.background ? `Setting: ${scene.background}` : '',
    scene.camera ? `Camera: ${scene.camera}` : '',
    scene.mood ? `Mood: ${scene.mood}` : '',
    scene.dialogue && scene.dialogue !== 'NONE' ? `Dialogue: "${scene.dialogue}"` : '',
  ].filter(Boolean);

  const positivePrompt = positivePromptParts.join('. ');
  const negativePrompt =
    'blurry, low quality, deformed, ugly, realistic photo, 3d render, watermark, text, bad anatomy, bad hands, extra fingers, mutation, disfigured, worst quality, low resolution, jpeg artifacts, static, no motion';

  const frameCount = Math.max(9, Math.floor(scene.duration * settings.fps));
  const seed = scene.seed || Math.floor(Math.random() * 9999999999);

  const workflow: Record<string, unknown> = {};
  const isGGUF = settings.modelFile.endsWith('.gguf');

  // Node 1: Load Model
  if (isGGUF) {
    workflow['1'] = { class_type: 'UnetLoaderGGUF', inputs: { unet_name: settings.modelFile } };
  } else {
    workflow['1'] = { class_type: 'CheckpointLoaderSimple', inputs: { ckpt_name: settings.modelFile } };
  }

  // Node 2: Load VAE
  workflow['2'] = { class_type: 'VAELoader', inputs: { vae_name: settings.vaeFile } };

  // Node 3: CLIP
  if (isGGUF) {
    workflow['3'] = { class_type: 'CLIPLoader', inputs: { clip_name: 't5xxl_fp8_e4m3fn.safetensors', type: 'flux' } };
  } else {
    workflow['3'] = { class_type: 'CheckpointLoaderSimple', inputs: { ckpt_name: settings.modelFile } };
  }

  // Node 4: Positive Prompt
  workflow['4'] = { class_type: 'CLIPTextEncode', inputs: { text: positivePrompt, clip: isGGUF ? ['3', 0] : ['3', 1] } };

  // Node 5: Negative Prompt
  workflow['5'] = { class_type: 'CLIPTextEncode', inputs: { text: negativePrompt, clip: isGGUF ? ['3', 0] : ['3', 1] } };

  // Node 6: Latent
  workflow['6'] = {
    class_type: 'EmptyHunyuanLatentVideo',
    inputs: { width: settings.width, height: settings.height, batch_size: frameCount, length: frameCount },
  };

  // Node 7: KSampler
  workflow['7'] = {
    class_type: 'KSampler',
    inputs: {
      model: ['1', 0],
      positive: ['4', 0],
      negative: ['5', 0],
      latent_image: ['6', 0],
      seed,
      steps: settings.steps,
      cfg: settings.cfg,
      sampler_name: settings.sampler,
      scheduler: settings.scheduler,
      denoise: 1.0,
    },
  };

  // Node 8: VAE Decode
  workflow['8'] = { class_type: 'VAEDecode', inputs: { samples: ['7', 0], vae: ['2', 0] } };

  // Node 9: Save
  if (useVHS) {
    workflow['9'] = {
      class_type: 'VHS_VideoCombine',
      inputs: {
        images: ['8', 0],
        frame_rate: settings.fps,
        loop_count: 0,
        filename_prefix: `ltx_anime/${scene.id}`,
        format: 'video/h264-mp4',
        pix_fmt: 'yuv420p',
        crf: 18,
        save_metadata: true,
      },
    };
  } else {
    workflow['9'] = { class_type: 'SaveImage', inputs: { filename_prefix: `ltx_anime/${scene.id}`, images: ['8', 0] } };
  }

  return workflow;
}
