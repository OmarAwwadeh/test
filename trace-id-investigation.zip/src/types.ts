export interface Character {
  id: string;
  name: string;
  appearance: string;
  color: string;
  role: 'protagonist' | 'antagonist' | 'supporting' | 'minor';
  consistentPrompt: string;
}

export interface Scene {
  id: string;
  title: string;
  description: string;
  characters: string[];
  camera: string;
  duration: number;
  background: string;
  mood: string;
  dialogue: string;
  seed?: number;
  status: 'pending' | 'generating' | 'done' | 'error';
  progress: number;
  error?: string;
  promptId?: string;
}

export interface Episode {
  id: string;
  title: string;
  scenes: Scene[];
}

export interface Project {
  id: string;
  name: string;
  description: string;
  style: string;
  episodes: Episode[];
  characters: Character[];
  createdAt: string;
}

export interface WorkflowSettings {
  width: number;
  height: number;
  fps: number;
  steps: number;
  cfg: number;
  sampler: string;
  scheduler: string;
  modelFile: string;
  vaeFile: string;
}

export interface Connections {
  comfyui: 'connected' | 'disconnected' | 'checking';
  ollama: 'connected' | 'disconnected' | 'checking';
  comfyuiUrl: string;
  ollamaUrl: string;
  comfyuiModels: string[];
  comfyuiVAEs: string[];
  ollamaModels: string[];
  hasVHS: boolean;
  hasGGUF: boolean;
  gpu: string;
  gpuMemory: string;
}
