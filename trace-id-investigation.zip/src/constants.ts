export const STYLE_PRESETS: Record<string, string> = {
  'Anime Classic': 'anime style, cel shaded, vibrant colors, clean lines, 2d animation, high quality',
  'Shonen': 'shonen anime style, dynamic action, bold lines, intense colors, dramatic poses, high quality',
  'Shojo': 'shojo anime style, soft pastel colors, sparkles, delicate features, romantic atmosphere, high quality',
  'Seinen': 'seinen anime style, detailed, realistic shading, mature themes, cinematic, high quality',
  'Cyberpunk': 'cyberpunk anime style, neon lights, futuristic, dark atmosphere, tech, high quality',
  'Fantasy': 'fantasy anime style, magical elements, mystical lighting, detailed backgrounds, high quality',
  'Mecha': 'mecha anime style, mechanical details, sci-fi, robots, epic scale, high quality',
  'Slice of Life': 'slice of life anime style, warm colors, cozy atmosphere, everyday scenes, high quality',
};

export const CAMERA_MOVEMENTS = [
  'static shot', 'slow pan left', 'slow pan right', 'pan up', 'pan down',
  'zoom in', 'zoom out', 'tracking shot', 'dolly in', 'dolly out',
  'bird eye view', 'low angle', 'high angle', 'close up', 'wide shot',
];

export const MOODS = [
  'Calm and peaceful', 'Action and excitement', 'Dramatic tension',
  'Romantic and soft', 'Mysterious and dark', 'Comedy and humor',
  'Sad and emotional', 'Triumphant and epic',
];

export const CHARACTER_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4',
  '#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e',
];

export const SETUP_GUIDE = [
  {
    title: 'Install Python 3.11',
    icon: '🐍',
    description: 'Required for ComfyUI and all dependencies',
    steps: [
      'Download from https://www.python.org/downloads/release/python-3119/',
      'Run installer - CHECK "Add Python to PATH"',
      'Verify: python --version',
    ],
    tip: 'Python 3.11 has best CUDA compatibility',
  },
  {
    title: 'Install CUDA Toolkit 12.1',
    icon: '🎮',
    description: 'Required for GPU acceleration with your GTX 1660 Ti',
    steps: [
      'Download from https://developer.nvidia.com/cuda-12-1-0-download-archive',
      'Select: Windows > x86_64 > 11 > exe (local)',
      'Run installer with Express settings',
      'Restart PC after installation',
    ],
    tip: 'Your GTX 1660 Ti supports CUDA compute capability 7.5',
  },
  {
    title: 'Install Git',
    icon: '📦',
    description: 'Needed to clone ComfyUI and extensions',
    steps: [
      'Download from https://git-scm.com/download/win',
      'Use default settings during installation',
      'Verify: git --version',
    ],
    tip: '',
  },
  {
    title: 'Install ComfyUI',
    icon: '🎨',
    description: 'The AI generation backend',
    steps: [
      'cd C:\\',
      'git clone https://github.com/comfyanonymous/ComfyUI.git',
      'cd ComfyUI',
      'python -m venv venv',
      'venv\\Scripts\\activate',
      'pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121',
      'pip install -r requirements.txt',
    ],
    tip: 'Virtual environment keeps dependencies isolated',
  },
  {
    title: 'Install ComfyUI Manager',
    icon: '🛠️',
    description: 'Makes installing custom nodes easier',
    steps: [
      'cd C:\\ComfyUI\\custom_nodes',
      'git clone https://github.com/ltdrdata/ComfyUI-Manager.git',
    ],
    tip: 'After this you can install nodes from ComfyUI web interface',
  },
  {
    title: 'Install LTX Video & Required Nodes',
    icon: '🎥',
    description: 'Install video generation custom nodes',
    steps: [
      'cd C:\\ComfyUI\\custom_nodes',
      'git clone https://github.com/Lightricks/ComfyUI-LTXVideo.git',
      'git clone https://github.com/city96/ComfyUI-GGUF.git',
      'git clone https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite.git',
      'cd C:\\ComfyUI',
      'venv\\Scripts\\activate',
      'pip install -r custom_nodes\\ComfyUI-LTXVideo\\requirements.txt',
      'pip install -r custom_nodes\\ComfyUI-GGUF\\requirements.txt',
      'pip install -r custom_nodes\\ComfyUI-VideoHelperSuite\\requirements.txt',
    ],
    tip: 'These nodes enable LTX-Video model loading and MP4 export',
  },
  {
    title: 'Download LTX-Video Models',
    icon: '⬇️',
    description: 'GGUF quantized model optimized for 6GB VRAM',
    steps: [
      '# Create directories',
      'mkdir C:\\ComfyUI\\models\\unet',
      'mkdir C:\\ComfyUI\\models\\vae',
      'mkdir C:\\ComfyUI\\models\\clip',
      '',
      '# Download GGUF Model (1.4GB - fits 6GB VRAM)',
      'curl -L -o C:\\ComfyUI\\models\\unet\\ltx-video-2b-Q4_K_M.gguf https://huggingface.co/city96/LTX-Video-2b-gguf/resolve/main/ltx-video-2b-Q4_K_M.gguf',
      '',
      '# Download VAE',
      'curl -L -o C:\\ComfyUI\\models\\vae\\ltx-video-2b.safetensors https://huggingface.co/Lightricks/LTX-Video/resolve/main/ltx-video-2b.safetensors',
      '',
      '# Download Text Encoder',
      'curl -L -o C:\\ComfyUI\\models\\clip\\t5xxl_fp8_e4m3fn.safetensors https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp8_e4m3fn.safetensors',
    ],
    tip: 'Q4_K_M quantization uses less VRAM while maintaining quality',
  },
  {
    title: 'Configure Low VRAM Settings',
    icon: '⚙️',
    description: 'Optimize for 6GB GTX 1660 Ti',
    steps: [
      '# Start ComfyUI with low VRAM mode:',
      'cd C:\\ComfyUI',
      'venv\\Scripts\\activate',
      'python main.py --lowvram --listen',
    ],
    tip: '--lowvram moves unused model parts to system RAM',
  },
  {
    title: 'Install Ollama (AI Story Generator)',
    icon: '🦙',
    description: 'Local AI for automatic story and character generation',
    steps: [
      '# Download from https://ollama.com/download/windows',
      '# After install, pull a model:',
      'ollama pull llama3.2',
      '',
      '# Or smaller model for less RAM usage:',
      'ollama pull gemma2:2b',
    ],
    tip: 'llama3.2 uses ~4GB RAM, gemma2:2b uses ~2GB RAM',
  },
  {
    title: 'Install FFmpeg (Video Export)',
    icon: '🎬',
    description: 'Required for MP4 export via VHS_VideoCombine',
    steps: [
      '# Download from https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip',
      '# Extract to C:\\ffmpeg',
      '# Add C:\\ffmpeg\\bin to System PATH:',
      '# 1. Right-click This PC > Properties > Advanced System Settings',
      '# 2. Click Environment Variables',
      '# 3. Under System Variables, find Path, click Edit',
      '# 4. Click New, add: C:\\ffmpeg\\bin',
      '# 5. Click OK, restart terminal',
      '',
      '# Verify:',
      'ffmpeg -version',
    ],
    tip: 'VHS_VideoCombine node requires FFmpeg to create MP4 files',
  },
  {
    title: 'Start Everything & Connect',
    icon: '🚀',
    description: 'Launch all services and connect this agent',
    steps: [
      '# Terminal 1 - Start ComfyUI:',
      'cd C:\\ComfyUI',
      'venv\\Scripts\\activate',
      'python main.py --lowvram --listen',
      '',
      '# Terminal 2 - Verify Ollama is running:',
      'ollama serve',
      '',
      '# Then click "Connect" in this agent!',
    ],
    tip: 'ComfyUI runs on port 8188, Ollama on port 11434',
  },
];

export const TROUBLESHOOTING = [
  { issue: 'CUDA Out of Memory', fix: 'Lower resolution to 512x384, reduce steps to 6, or restart ComfyUI with --lowvram' },
  { issue: 'Model not found', fix: 'Check files in ComfyUI/models/unet/, models/vae/, models/clip/' },
  { issue: 'VHS_VideoCombine missing', fix: 'git clone ComfyUI-VideoHelperSuite in custom_nodes folder' },
  { issue: 'Generation is slow', fix: 'Use GGUF Q4_K_M model, reduce steps to 8, lower resolution' },
  { issue: 'Ollama not responding', fix: 'Run: ollama serve, then ollama pull llama3.2' },
  { issue: 'Black/green output', fix: 'Update ComfyUI-LTXVideo, check VAE file is correct' },
  { issue: 'Missing node type error', fix: 'Restart ComfyUI after installing new custom nodes' },
];
