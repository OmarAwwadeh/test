import { useState, useEffect, useCallback } from 'react';

/* ============================================
   TYPES
============================================ */
interface Character {
  id: string;
  name: string;
  appearance: string;
  color: string;
  role: string;
  consistentPrompt: string;
}

interface Scene {
  id: string;
  title: string;
  description: string;
  characters: string[];
  camera: string;
  duration: number;
  background: string;
  mood: string;
  dialogue: string;
  seed: number;
  status: 'pending' | 'generating' | 'done' | 'error';
  progress: number;
  promptId?: string;
  error?: string;
}

interface Episode {
  id: string;
  title: string;
  scenes: Scene[];
}

interface Project {
  id: string;
  name: string;
  description: string;
  style: string;
  episodes: Episode[];
  characters: Character[];
  createdAt: string;
}

interface ConnectionStatus {
  comfyui: 'connected' | 'disconnected' | 'checking';
  ollama: 'connected' | 'disconnected' | 'checking';
  comfyuiUrl: string;
  ollamaUrl: string;
  comfyuiModels: string[];
  comfyuiVAEs: string[];
  ollamaModels: string[];
  hasVHS: boolean;
  hasGGUF: boolean;
  gpu: string;
  gpuMemory: string;
}

interface WorkflowSettings {
  width: number;
  height: number;
  fps: number;
  steps: number;
  cfg: number;
  sampler: string;
  scheduler: string;
  modelFile: string;
  vaeFile: string;
}

/* ============================================
   CONSTANTS
============================================ */
const STYLE_PRESETS: Record<string, string> = {
  'Anime Classic': 'anime style, cel shaded, vibrant colors, clean lines, 2d animation, high quality',
  'Shonen': 'shonen anime style, dynamic action, bold lines, intense colors, dramatic poses, high quality',
  'Shojo': 'shojo anime style, soft pastel colors, sparkles, delicate features, romantic atmosphere, high quality',
  'Seinen': 'seinen anime style, detailed, realistic shading, mature themes, cinematic, high quality',
  'Cyberpunk': 'cyberpunk anime style, neon lights, futuristic, dark atmosphere, tech, high quality',
  'Fantasy': 'fantasy anime style, magical elements, mystical lighting, detailed backgrounds, high quality',
  'Mecha': 'mecha anime style, mechanical details, sci-fi, robots, epic scale, high quality',
  'Slice of Life': 'slice of life anime style, warm colors, cozy atmosphere, everyday scenes, high quality',
};

const CAMERA_MOVEMENTS = [
  'static shot', 'slow pan left', 'slow pan right', 'pan up', 'pan down',
  'zoom in', 'zoom out', 'tracking shot', 'dolly in', 'dolly out',
  'bird eye view', 'low angle', 'high angle', 'close up', 'wide shot',
];

const MOODS = [
  'Calm and peaceful', 'Action and excitement', 'Dramatic tension',
  'Romantic and soft', 'Mysterious and dark', 'Comedy and humor',
  'Sad and emotional', 'Triumphant and epic',
];

const CHARACTER_COLORS = [
  '#ef4444', '#f97316', '#eab308', '#22c55e', '#06b6d4',
  '#3b82f6', '#8b5cf6', '#ec4899', '#14b8a6', '#f43f5e',
];

/* ============================================
   WORKFLOW GENERATOR - Using proper LTX Video nodes
============================================ */
function generateWorkflow(
  scene: Scene,
  settings: WorkflowSettings,
  project: Project,
  useVHS: boolean = true
): Record<string, any> {
  const chars = scene.characters
    .map((id) => project.characters.find((c) => c.id === id))
    .filter(Boolean) as Character[];

  const charDescriptions = chars.length > 0
    ? chars.map((c) => `${c.name}: ${c.appearance}. ${c.consistentPrompt}`).join('. ')
    : '';

  const style = STYLE_PRESETS[project.style] || STYLE_PRESETS['Anime Classic'];

  const positivePromptParts = [
    style,
    scene.description,
    charDescriptions ? `Characters: ${charDescriptions}` : '',
    scene.background ? `Setting: ${scene.background}` : '',
    scene.camera ? `Camera: ${scene.camera}` : '',
    scene.mood ? `Mood: ${scene.mood}` : '',
    scene.dialogue && scene.dialogue !== 'NONE' ? `Dialogue: "${scene.dialogue}"` : '',
  ].filter(Boolean);

  const positivePrompt = positivePromptParts.join('. ');

  const negativePrompt = 'blurry, low quality, deformed, ugly, realistic photo, 3d render, watermark, text, bad anatomy, bad hands, extra fingers, mutation, disfigured, worst quality, low resolution, jpeg artifacts, static, no motion';

  const frameCount = Math.max(9, Math.floor(scene.duration * settings.fps));
  const seed = scene.seed || Math.floor(Math.random() * 9999999999);

  // Build workflow with proper LTX Video node structure
  // Uses LTXVImgToVideo for text-to-video generation
  const workflow: Record<string, any> = {};

  // Node 1: Load Model
  if (settings.modelFile.endsWith('.gguf')) {
    workflow['1'] = {
      class_type: 'UnetLoaderGGUF',
      inputs: { unet_name: settings.modelFile },
    };
  } else {
    workflow['1'] = {
      class_type: 'CheckpointLoaderSimple',
      inputs: { ckpt_name: settings.modelFile },
    };
  }

  // Node 2: Load VAE
  workflow['2'] = {
    class_type: 'VAELoader',
    inputs: { vae_name: settings.vaeFile },
  };

  // Node 3: Text Encoder (CLIP) - Get CLIP from checkpoint or model
  if (settings.modelFile.endsWith('.gguf')) {
    // For GGUF, we need a separate CLIP loader
    workflow['3'] = {
      class_type: 'CLIPLoader',
      inputs: {
        clip_name: 't5xxl_fp8_e4m3fn.safetensors',
        type: 'flux',
      },
    };
  } else {
    // Checkpoint has built-in CLIP, extract it
    workflow['3'] = {
      class_type: 'CheckpointLoaderSimple',
      inputs: { ckpt_name: settings.modelFile },
    };
  }

  // Node 4: Positive Prompt
  workflow['4'] = {
    class_type: 'CLIPTextEncode',
    inputs: {
      text: positivePrompt,
      clip: settings.modelFile.endsWith('.gguf') ? ['3', 0] : ['3', 1],
    },
  };

  // Node 5: Negative Prompt
  workflow['5'] = {
    class_type: 'CLIPTextEncode',
    inputs: {
      text: negativePrompt,
      clip: settings.modelFile.endsWith('.gguf') ? ['3', 0] : ['3', 1],
    },
  };

  // Node 6: Create Video Latent (LTX uses EmptyHunyuanLatentVideo for video)
  workflow['6'] = {
    class_type: 'EmptyHunyuanLatentVideo',
    inputs: {
      width: settings.width,
      height: settings.height,
      batch_size: frameCount,
      length: frameCount,
    },
  };

  // Node 7: Sampler
  workflow['7'] = {
    class_type: 'KSampler',
    inputs: {
      model: settings.modelFile.endsWith('.gguf') ? ['1', 0] : ['1', 0],
      positive: ['4', 0],
      negative: ['5', 0],
      latent_image: ['6', 0],
      seed: seed,
      steps: settings.steps,
      cfg: settings.cfg,
      sampler_name: settings.sampler,
      scheduler: settings.scheduler,
      denoise: 1.0,
    },
  };

  // Node 8: Decode Latent to Images
  workflow['8'] = {
    class_type: 'VAEDecode',
    inputs: {
      samples: ['7', 0],
      vae: ['2', 0],
    },
  };

  // Node 9: Save/Export
  if (useVHS) {
    workflow['9'] = {
      class_type: 'VHS_VideoCombine',
      inputs: {
        images: ['8', 0],
        frame_rate: settings.fps,
        loop_count: 0,
        filename_prefix: `ltx_anime/${scene.id}`,
        format: 'video/h264-mp4',
        pix_fmt: 'yuv420p',
        crf: 18,
        save_metadata: true,
      },
    };
  } else {
    workflow['9'] = {
      class_type: 'SaveImage',
      inputs: {
        filename_prefix: `ltx_anime/${scene.id}`,
        images: ['8', 0],
      },
    };
  }

  return workflow;
}

/* ============================================
   SETUP GUIDE
============================================ */
const SETUP_GUIDE = [
  {
    title: 'Install Python 3.11',
    icon: '🐍',
    description: 'Required for ComfyUI and all dependencies',
    steps: [
      'Download from https://www.python.org/downloads/release/python-3119/',
      'Run installer - CHECK "Add Python to PATH"',
      'Verify: python --version',
    ],
    tip: 'Python 3.11 has best CUDA compatibility',
  },
  {
    title: 'Install CUDA Toolkit 12.1',
    icon: '🎮',
    description: 'Required for GPU acceleration with your GTX 1660 Ti',
    steps: [
      'Download from https://developer.nvidia.com/cuda-12-1-0-download-archive',
      'Select: Windows > x86_64 > 11 > exe (local)',
      'Run installer with Express settings',
      'Restart PC after installation',
    ],
    tip: 'Your GTX 1660 Ti supports CUDA compute capability 7.5',
  },
  {
    title: 'Install Git',
    icon: '📦',
    description: 'Needed to clone ComfyUI and extensions',
    steps: [
      'Download from https://git-scm.com/download/win',
      'Use default settings during installation',
      'Verify: git --version',
    ],
    tip: '',
  },
  {
    title: 'Install ComfyUI',
    icon: '🎨',
    description: 'The AI generation backend',
    steps: [
      'cd C:\\',
      'git clone https://github.com/comfyanonymous/ComfyUI.git',
      'cd ComfyUI',
      'python -m venv venv',
      'venv\\Scripts\\activate',
      'pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu121',
      'pip install -r requirements.txt',
    ],
    tip: 'Virtual environment keeps dependencies isolated',
  },
  {
    title: 'Install ComfyUI Manager',
    icon: '🛠️',
    description: 'Makes installing custom nodes easier',
    steps: [
      'cd C:\\ComfyUI\\custom_nodes',
      'git clone https://github.com/ltdrdata/ComfyUI-Manager.git',
    ],
    tip: 'After this you can install nodes from ComfyUI web interface',
  },
  {
    title: 'Install LTX Video & Required Nodes',
    icon: '🎥',
    description: 'Install video generation custom nodes',
    steps: [
      'cd C:\\ComfyUI\\custom_nodes',
      'git clone https://github.com/Lightricks/ComfyUI-LTXVideo.git',
      'git clone https://github.com/city96/ComfyUI-GGUF.git',
      'git clone https://github.com/Kosinkadink/ComfyUI-VideoHelperSuite.git',
      'cd C:\\ComfyUI',
      'venv\\Scripts\\activate',
      'pip install -r custom_nodes\\ComfyUI-LTXVideo\\requirements.txt',
      'pip install -r custom_nodes\\ComfyUI-GGUF\\requirements.txt',
      'pip install -r custom_nodes\\ComfyUI-VideoHelperSuite\\requirements.txt',
    ],
    tip: 'These nodes enable LTX-Video model loading and MP4 export',
  },
  {
    title: 'Download LTX-Video Models',
    icon: '⬇️',
    description: 'GGUF quantized model optimized for 6GB VRAM',
    steps: [
      '# Create directories',
      'mkdir C:\\ComfyUI\\models\\unet',
      'mkdir C:\\ComfyUI\\models\\vae',
      'mkdir C:\\ComfyUI\\models\\clip',
      '',
      '# Download GGUF Model (1.4GB - fits 6GB VRAM)',
      'curl -L -o C:\\ComfyUI\\models\\unet\\ltx-video-2b-Q4_K_M.gguf https://huggingface.co/city96/LTX-Video-2b-gguf/resolve/main/ltx-video-2b-Q4_K_M.gguf',
      '',
      '# Download VAE',
      'curl -L -o C:\\ComfyUI\\models\\vae\\ltx-video-2b.safetensors https://huggingface.co/Lightricks/LTX-Video/resolve/main/ltx-video-2b.safetensors',
      '',
      '# Download Text Encoder',
      'curl -L -o C:\\ComfyUI\\models\\clip\\t5xxl_fp8_e4m3fn.safetensors https://huggingface.co/comfyanonymous/flux_text_encoders/resolve/main/t5xxl_fp8_e4m3fn.safetensors',
    ],
    tip: 'Q4_K_M quantization uses less VRAM while maintaining quality',
  },
  {
    title: 'Configure Low VRAM Settings',
    icon: '⚙️',
    description: 'Optimize for 6GB GTX 1660 Ti',
    steps: [
      '# Start ComfyUI with low VRAM mode:',
      'cd C:\\ComfyUI',
      'venv\\Scripts\\activate',
      'python main.py --lowvram --listen',
    ],
    tip: '--lowvram moves unused model parts to system RAM',
  },
  {
    title: 'Install Ollama (AI Story Generator)',
    icon: '🦙',
    description: 'Local AI for automatic story and character generation',
    steps: [
      '# Download from https://ollama.com/download/windows',
      '# After install, pull a model:',
      'ollama pull llama3.2',
      '',
      '# Or smaller model for less RAM usage:',
      'ollama pull gemma2:2b',
    ],
    tip: 'llama3.2 uses ~4GB RAM, gemma2:2b uses ~2GB RAM',
  },
  {
    title: 'Install FFmpeg (Video Export)',
    icon: '🎬',
    description: 'Required for MP4 export via VHS_VideoCombine',
    steps: [
      '# Download from https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip',
      '# Extract to C:\\ffmpeg',
      '# Add C:\\ffmpeg\\bin to System PATH:',
      '# 1. Right-click This PC > Properties > Advanced System Settings',
      '# 2. Click Environment Variables',
      '# 3. Under System Variables, find Path, click Edit',
      '# 4. Click New, add: C:\\ffmpeg\\bin',
      '# 5. Click OK, restart terminal',
      '',
      '# Verify:',
      'ffmpeg -version',
    ],
    tip: 'VHS_VideoCombine node requires FFmpeg to create MP4 files',
  },
  {
    title: 'Start Everything & Connect',
    icon: '🚀',
    description: 'Launch all services and connect this agent',
    steps: [
      '# Terminal 1 - Start ComfyUI:',
      'cd C:\\ComfyUI',
      'venv\\Scripts\\activate',
      'python main.py --lowvram --listen',
      '',
      '# Terminal 2 - Verify Ollama is running:',
      'ollama serve',
      '',
      '# Then click "Connect" in this agent!',
    ],
    tip: 'ComfyUI runs on port 8188, Ollama on port 11434',
  },
];

const TROUBLESHOOTING = [
  { issue: 'CUDA Out of Memory', fix: 'Lower resolution to 512x384, reduce steps to 6, or restart ComfyUI with --lowvram' },
  { issue: 'Model not found', fix: 'Check files in ComfyUI/models/unet/, models/vae/, models/clip/' },
  { issue: 'VHS_VideoCombine missing', fix: 'git clone ComfyUI-VideoHelperSuite in custom_nodes folder' },
  { issue: 'Generation is slow', fix: 'Use GGUF Q4_K_M model, reduce steps to 8, lower resolution' },
  { issue: 'Ollama not responding', fix: 'Run: ollama serve, then ollama pull llama3.2' },
  { issue: 'Black/green output', fix: 'Update ComfyUI-LTXVideo, check VAE file is correct' },
  { issue: 'Missing node type error', fix: 'Restart ComfyUI after installing new custom nodes' },
];

/* ============================================
   MAIN APP
============================================ */
export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem('ltx2-agent-projects');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [selectedEpisode, setSelectedEpisode] = useState<string | null>(null);
  const [generating, setGenerating] = useState(false);
  const [logs, setLogs] = useState<string[]>([]);
  const [showLog, setShowLog] = useState(false);
  const [aiGenerating, setAiGenerating] = useState(false);
  const [expandedGuide, setExpandedGuide] = useState<number | null>(null);

  const [connections, setConnections] = useState<ConnectionStatus>({
    comfyui: 'disconnected',
    ollama: 'disconnected',
    comfyuiUrl: 'http://127.0.0.1:8188',
    ollamaUrl: 'http://127.0.0.1:11434',
    comfyuiModels: [],
    comfyuiVAEs: [],
    ollamaModels: [],
    hasVHS: false,
    hasGGUF: false,
    gpu: 'Unknown',
    gpuMemory: 'Unknown',
  });

  const [settings, setSettings] = useState<WorkflowSettings>({
    width: 512,
    height: 384,
    fps: 24,
    steps: 8,
    cfg: 3.0,
    sampler: 'euler',
    scheduler: 'normal',
    modelFile: 'ltx-video-2b-Q4_K_M.gguf',
    vaeFile: 'ltx-video-2b.safetensors',
  });

  // Save projects
  useEffect(() => {
    localStorage.setItem('ltx2-agent-projects', JSON.stringify(projects));
  }, [projects]);

  // Add log
  const addLog = useCallback((msg: string) => {
    const time = new Date().toLocaleTimeString();
    setLogs((prev) => [`[${time}] ${msg}`, ...prev.slice(0, 50)]);
  }, []);

  // Check connections
  const checkConnections = useCallback(async () => {
    setConnections((p) => ({ ...p, comfyui: 'checking', ollama: 'checking' }));
    addLog('🔍 Checking connections...');

    // Check ComfyUI
    try {
      const res = await fetch(`${connections.comfyuiUrl}/system_stats`);
      if (res.ok) {
        const data = await res.json();
        const gpuName = data.devices?.[0]?.name || 'GPU';
        const gpuMem = data.devices?.[0]?.vram_total
          ? `${(data.devices[0].vram_total / 1073741824).toFixed(1)}GB`
          : '?';
        addLog(`✅ ComfyUI connected - ${gpuName} (${gpuMem})`);

        // Check available nodes and models
        try {
          const objRes = await fetch(`${connections.comfyuiUrl}/object_info`);
          const objData = await objRes.json();

          const checkpoints = objData.CheckpointLoaderSimple?.input?.required?.ckpt_name?.[0] || [];
          const unets = objData.UnetLoaderGGUF?.input?.required?.unet_name?.[0] || [];
          const vaes = objData.VAELoader?.input?.required?.vae_name?.[0] || [];
          const allModels = [...checkpoints, ...unets];

          const hasVHS = !!objData.VHS_VideoCombine;
          const hasGGUF = !!objData.UnetLoaderGGUF;

          setConnections((p) => ({
            ...p,
            comfyui: 'connected',
            comfyuiModels: allModels,
            comfyuiVAEs: vaes,
            hasVHS,
            hasGGUF,
            gpu: gpuName,
            gpuMemory: gpuMem,
          }));

          if (!hasVHS) addLog('⚠️ VHS_VideoCombine not found - install ComfyUI-VideoHelperSuite');
          if (!hasGGUF) addLog('ℹ️ GGUF node not found - only checkpoint models available');
          if (allModels.length === 0) addLog('⚠️ No models found - place .gguf files in models/unet/');
          if (vaes.length === 0) addLog('⚠️ No VAE found - place ltx-video-2b.safetensors in models/vae/');
        } catch {
          setConnections((p) => ({ ...p, comfyui: 'connected' }));
        }
      } else {
        setConnections((p) => ({ ...p, comfyui: 'disconnected' }));
        addLog('❌ ComfyUI not responding');
      }
    } catch {
      setConnections((p) => ({ ...p, comfyui: 'disconnected' }));
      addLog('❌ Cannot connect to ComfyUI - is it running on port 8188?');
    }

    // Check Ollama
    try {
      const res = await fetch(`${connections.ollamaUrl}/api/tags`);
      if (res.ok) {
        const data = await res.json();
        const models = data.models?.map((m: { name: string }) => m.name) || [];
        setConnections((p) => ({ ...p, ollama: 'connected', ollamaModels: models }));
        addLog(`✅ Ollama connected${models.length > 0 ? ` - ${models.length} models` : ' - no models installed'}`);
        if (models.length === 0) addLog('💡 Run: ollama pull llama3.2');
      } else {
        setConnections((p) => ({ ...p, ollama: 'disconnected' }));
        addLog('❌ Ollama not responding');
      }
    } catch {
      setConnections((p) => ({ ...p, ollama: 'disconnected' }));
      addLog('❌ Cannot connect to Ollama - is it running on port 11434?');
    }
  }, [connections.comfyuiUrl, connections.ollamaUrl, addLog]);

  // Auto-check on mount
  useEffect(() => {
    const timer = setTimeout(checkConnections, 500);
    return () => clearTimeout(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Ask Ollama
  const askOllama = async (prompt: string): Promise<string> => {
    try {
      const model = connections.ollamaModels[0] || 'llama3.2';
      const res = await fetch(`${connections.ollamaUrl}/api/generate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          model,
          prompt,
          stream: false,
          options: { temperature: 0.7, num_predict: 4000 },
        }),
      });
      const data = await res.json();
      return data.response || '';
    } catch {
      addLog('❌ Ollama generation failed');
      return '';
    }
  };

  // AI Generate Characters
  const aiGenerateCharacters = async () => {
    if (!selectedProject || connections.ollama !== 'connected') return;
    setAiGenerating(true);
    addLog('🤖 Generating characters with AI...');

    const prompt = `Create exactly 4 unique anime characters for "${selectedProject.name}" (${selectedProject.style} style).
Description: ${selectedProject.description}

Use EXACTLY this format for each character:

CHARACTER: [Name]
ROLE: [protagonist/antagonist/supporting/minor]
APPEARANCE: [detailed visual: hair color/style, eye color, clothing, distinguishing features]
CONSISTENT: [short phrase for consistent rendering, e.g. "blue-haired girl with red eyes"]

Make characters visually distinct and memorable.`;

    const response = await askOllama(prompt);
    const blocks = response.split(/CHARACTER:/i).filter((b: string) => b.trim());
    const newChars: Character[] = [];

    for (const block of blocks.slice(0, 4)) {
      const lines = block.trim().split('\n').map((l: string) => l.trim()).filter(Boolean);
      const name = lines[0]?.replace(/[:.]/g, '').trim() || '';

      const getVal = (key: string) => {
        const line = lines.find((l: string) => l.toLowerCase().startsWith(key.toLowerCase() + ':'));
        return line?.split(':').slice(1).join(':').trim() || '';
      };

      const roleStr = getVal('ROLE').toLowerCase();
      const role = roleStr.includes('protagonist') ? 'protagonist'
        : roleStr.includes('antagonist') ? 'antagonist'
        : roleStr.includes('minor') ? 'minor' : 'supporting';

      const appearance = getVal('APPEARANCE') || 'anime character';
      const consistent = getVal('CONSISTENT') || `same ${name} character`;

      if (name.length > 1 && name.length < 30) {
        newChars.push({
          id: `char_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          name,
          appearance,
          color: CHARACTER_COLORS[newChars.length % CHARACTER_COLORS.length],
          role,
          consistentPrompt: consistent,
        });
      }
    }

    // Fallback if AI fails
    if (newChars.length === 0) {
      const ts = Date.now();
      newChars.push(
        { id: `char_${ts}_1`, name: 'Hero', appearance: 'young person with bright eyes, blue jacket, dark spiky hair', color: '#3b82f6', role: 'protagonist', consistentPrompt: 'same Hero, blue jacket' },
        { id: `char_${ts}_2`, name: 'Rival', appearance: 'tall figure, sharp features, long dark hair, dark clothing', color: '#8b5cf6', role: 'antagonist', consistentPrompt: 'same Rival, dark hair' },
        { id: `char_${ts}_3`, name: 'Friend', appearance: 'cheerful face, round features, bright smile, colorful clothes', color: '#22c55e', role: 'supporting', consistentPrompt: 'same Friend, colorful clothes' },
        { id: `char_${ts}_4`, name: 'Mentor', appearance: 'wise elder, distinctive beard, traditional robes', color: '#f97316', role: 'supporting', consistentPrompt: 'same Mentor, robes' }
      );
      addLog('📝 Created 4 default characters');
    }

    setProjects(prev => prev.map(p =>
      p.id === selectedProject.id
        ? { ...p, characters: [...p.characters, ...newChars] }
        : p
    ));
    setSelectedProject(prev => prev ? { ...prev, characters: [...prev.characters, ...newChars] } : null);
    addLog(`✅ Generated ${newChars.length} characters`);
    setAiGenerating(false);
  };

  // AI Generate Story
  const aiGenerateStory = async () => {
    if (!selectedProject || connections.ollama !== 'connected') return;
    setAiGenerating(true);
    addLog('🤖 Generating episode story with AI...');

    const charDesc = selectedProject.characters
      .map(c => `- ${c.name} (${c.role}): ${c.appearance}`)
      .join('\n');

    const prompt = `Create an anime episode with 5-8 scenes for "${selectedProject.name}" (${selectedProject.style}).
Story: ${selectedProject.description}

Characters:
${charDesc}

For each scene use EXACTLY this format:

SCENE: [Title]
DESCRIPTION: [what happens, 1-2 sentences]
CHARACTERS: [character names present]
CAMERA: [static shot/pan left/pan right/zoom in/zoom out/tracking shot]
BACKGROUND: [detailed setting]
MOOD: [Calm/Action/Dramatic/Romantic/Mysterious/Comedy/Sad/Epic]
DURATION: [2-5 seconds number]
DIALOGUE: [line or NONE]

Create a compelling story arc with beginning, middle, end.`;

    const response = await askOllama(prompt);
    const sceneBlocks = response.split(/SCENE:/i).filter((b: string) => b.trim());
    const newScenes: Scene[] = [];

    for (const block of sceneBlocks.slice(0, 8)) {
      const lines = block.trim().split('\n').map((l: string) => l.trim()).filter(Boolean);
      const title = lines[0]?.replace(/[:]/g, '').trim() || '';

      const getVal = (key: string) => {
        const line = lines.find((l: string) => l.toLowerCase().startsWith(key.toLowerCase() + ':'));
        return line?.split(':').slice(1).join(':').trim() || '';
      };

      const desc = getVal('DESCRIPTION') || 'A scene';
      const charNames = getVal('CHARACTERS') || '';
      const camera = getVal('CAMERA') || 'static shot';
      const background = getVal('BACKGROUND') || 'anime background';
      const mood = getVal('MOOD') || 'Calm and peaceful';
      const duration = Math.min(10, Math.max(2, parseInt(getVal('DURATION')) || 3));
      const dialogue = getVal('DIALOGUE') || '';

      const matchedChars = selectedProject.characters
        .filter(c => charNames.toLowerCase().includes(c.name.toLowerCase()))
        .map(c => c.id);

      if (matchedChars.length === 0) {
        const protag = selectedProject.characters.find(c => c.role === 'protagonist');
        if (protag) matchedChars.push(protag.id);
      }

      if (title.length > 1) {
        newScenes.push({
          id: `scene_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
          title,
          description: desc,
          characters: matchedChars,
          camera,
          duration,
          background,
          mood,
          dialogue: dialogue.toUpperCase() === 'NONE' ? '' : dialogue,
          seed: Math.floor(Math.random() * 9999999999),
          status: 'pending',
          progress: 0,
        });
      }
    }

    // Fallback scenes
    if (newScenes.length === 0) {
      const protag = selectedProject.characters.find(c => c.role === 'protagonist');
      newScenes.push(
        { id: `scene_${Date.now()}_1`, title: 'Opening', description: 'The story begins with a beautiful vista', characters: protag ? [protag.id] : [], camera: 'slow pan right', duration: 3, background: 'beautiful anime landscape at dawn', mood: 'Calm and peaceful', dialogue: '', seed: Math.floor(Math.random() * 9999999999), status: 'pending', progress: 0 },
        { id: `scene_${Date.now()}_2`, title: 'The Call', description: 'Something unexpected happens', characters: selectedProject.characters.slice(0, 2).map(c => c.id), camera: 'zoom in', duration: 4, background: 'dramatic interior scene', mood: 'Dramatic tension', dialogue: '', seed: Math.floor(Math.random() * 9999999999), status: 'pending', progress: 0 }
      );
      addLog('📝 Created 2 default scenes');
    }

    const newEpisode: Episode = {
      id: `ep_${Date.now()}`,
      title: `Episode ${selectedProject.episodes.length + 1}`,
      scenes: newScenes,
    };

    setProjects(prev => prev.map(p =>
      p.id === selectedProject.id
        ? { ...p, episodes: [...p.episodes, newEpisode] }
        : p
    ));
    setSelectedProject(prev => prev ? { ...prev, episodes: [...prev.episodes, newEpisode] } : null);
    setSelectedEpisode(newEpisode.id);
    addLog(`✅ Generated ${newScenes.length} scenes`);
    setAiGenerating(false);
  };

  // Queue scene to ComfyUI
  const queueScene = async (scene: Scene, epIndex: number, scIndex: number) => {
    if (connections.comfyui !== 'connected' || !selectedProject) {
      addLog('❌ ComfyUI not connected');
      return;
    }

    const updateSceneState = (updates: Partial<Scene>) => {
      const updateFn = (p: Project) => {
        const eps = [...p.episodes];
        eps[epIndex] = { ...eps[epIndex], scenes: [...eps[epIndex].scenes] };
        eps[epIndex].scenes[scIndex] = { ...eps[epIndex].scenes[scIndex], ...updates };
        return { ...p, episodes: eps };
      };
      setProjects(prev => prev.map(p => p.id === selectedProject.id ? updateFn(p) : p));
      setSelectedProject(prev => prev && prev.id === selectedProject.id ? updateFn(prev) : prev);
    };

    updateSceneState({ status: 'generating', progress: 0, error: undefined });
    addLog(`🎬 Queuing: ${scene.title}`);

    try {
      let workflow = generateWorkflow(scene, settings, selectedProject, connections.hasVHS);

      const res = await fetch(`${connections.comfyuiUrl}/prompt`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: workflow }),
      });

      let result = await res.json();

      if (result.error) {
        if (result.error.type === 'missing_node_type') {
          if (result.error.message?.includes('VHS')) {
            addLog('⚠️ VHS not found, using SaveImage fallback...');
            workflow = generateWorkflow(scene, settings, selectedProject, false);
            const res2 = await fetch(`${connections.comfyuiUrl}/prompt`, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ prompt: workflow }),
            });
            result = await res2.json();
            if (result.error) throw new Error(result.error.message || 'Fallback workflow failed');
          } else {
            throw new Error(`Missing node: ${result.error.message}`);
          }
        } else {
          throw new Error(result.error.message || 'Workflow error');
        }
      }

      if (!result.prompt_id) throw new Error('No prompt_id returned');
      addLog(`✅ Queued: ${scene.title} (ID: ${result.prompt_id})`);
      updateSceneState({ promptId: result.prompt_id });

      // Poll for completion
      let attempts = 0;
      while (attempts < 600) {
        await new Promise(r => setTimeout(r, 1000));
        attempts++;
        try {
          const histRes = await fetch(`${connections.comfyuiUrl}/history/${result.prompt_id}`);
          const histData = await histRes.json();

          if (histData[result.prompt_id]?.status?.completed) {
            updateSceneState({ status: 'done', progress: 100 });
            addLog(`✅ Completed: ${scene.title}`);
            return;
          }
          if (histData[result.prompt_id]?.status?.status_str === 'error') {
            throw new Error('ComfyUI generation error');
          }
          updateSceneState({ progress: Math.min(95, Math.floor((attempts / 300) * 100)) });
        } catch (e) {
          if (e instanceof Error && e.message.includes('ComfyUI')) throw e;
        }
      }
      throw new Error('Generation timeout (10 min)');
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'Unknown error';
      updateSceneState({ status: 'error', progress: 0, error: msg });
      addLog(`❌ Failed: ${scene.title} - ${msg}`);
    }
  };

  // Generate all scenes in episode
  const generateEpisode = async () => {
    if (!selectedProject || !selectedEpisode) return;
    const epIndex = selectedProject.episodes.findIndex(e => e.id === selectedEpisode);
    if (epIndex === -1) return;

    const episode = selectedProject.episodes[epIndex];
    setGenerating(true);
    addLog(`🎬 Starting episode: ${episode.title}`);

    for (let i = 0; i < episode.scenes.length; i++) {
      if (episode.scenes[i].status === 'done') continue;
      await queueScene(episode.scenes[i], epIndex, i);
      await new Promise(r => setTimeout(r, 500));
    }

    setGenerating(false);
    addLog(`✅ Episode complete: ${episode.title}`);
  };

  // Download workflow JSON
  const downloadWorkflow = (scene: Scene) => {
    if (!selectedProject) return;
    const wf = generateWorkflow(scene, settings, selectedProject, connections.hasVHS);
    const blob = new Blob([JSON.stringify(wf, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${scene.title.replace(/[^a-zA-Z0-9]/g, '_')}_workflow.json`;
    a.click();
    URL.revokeObjectURL(url);
    addLog(`📥 Downloaded workflow: ${scene.title}`);
  };

  // Download batch script
  const downloadBatchScript = () => {
    if (!selectedProject) return;
    const script = `@echo off
REM ============================================
REM LTX-2 Anime Video Batch Processor
REM Project: ${selectedProject.name}
REM ============================================
echo Starting batch video generation...
echo.

set COMFYUI_URL=http://127.0.0.1:8188
set OUTPUT_DIR=output\\${selectedProject.name.replace(/[^a-zA-Z0-9]/g, '_')}

mkdir %OUTPUT_DIR% 2>nul

${selectedProject.episodes.map((ep) => `
REM === ${ep.title} ===
echo Processing ${ep.title}...
${ep.scenes.map((sc, si) => `
echo   Scene ${si + 1}: ${sc.title}
curl -X POST %COMFYUI_URL%/prompt -H "Content-Type: application/json" -d @${sc.title.replace(/[^a-zA-Z0-9]/g, '_')}_workflow.json
timeout /t 5 /nobreak >nul
`).join('')}
`).join('')}

echo.
echo All scenes queued! Check ComfyUI web interface for progress.
echo Videos will be saved in ComfyUI/output/ltx_anime/
pause`;

    const blob = new Blob([script], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${selectedProject.name.replace(/[^a-zA-Z0-9]/g, '_')}_batch.bat`;
    a.click();
    URL.revokeObjectURL(url);
    addLog('📥 Downloaded batch script');
  };

  // Project CRUD
  const createProject = (name: string, description: string, style: string) => {
    const newProject: Project = {
      id: `proj_${Date.now()}`,
      name,
      description,
      style,
      episodes: [],
      characters: [],
      createdAt: new Date().toISOString(),
    };
    setProjects(prev => [...prev, newProject]);
    setSelectedProject(newProject);
    setActiveTab('project');
    addLog(`✅ Created project: ${name}`);
  };

  const deleteProject = (id: string) => {
    setProjects(prev => prev.filter(p => p.id !== id));
    if (selectedProject?.id === id) {
      setSelectedProject(null);
      setSelectedEpisode(null);
    }
    addLog('🗑️ Deleted project');
  };

  // Character CRUD
  const addCharacter = () => {
    if (!selectedProject) return;
    const char: Character = {
      id: `char_${Date.now()}`,
      name: 'New Character',
      appearance: '',
      color: CHARACTER_COLORS[selectedProject.characters.length % CHARACTER_COLORS.length],
      role: 'supporting',
      consistentPrompt: '',
    };
    const updated = { ...selectedProject, characters: [...selectedProject.characters, char] };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const updateCharacter = (id: string, field: keyof Character, value: string) => {
    if (!selectedProject) return;
    const updated = {
      ...selectedProject,
      characters: selectedProject.characters.map(c => c.id === id ? { ...c, [field]: value } : c),
    };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const deleteCharacter = (id: string) => {
    if (!selectedProject) return;
    const updated = { ...selectedProject, characters: selectedProject.characters.filter(c => c.id !== id) };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  // Episode CRUD
  const addEpisode = () => {
    if (!selectedProject) return;
    const ep: Episode = {
      id: `ep_${Date.now()}`,
      title: `Episode ${selectedProject.episodes.length + 1}`,
      scenes: [],
    };
    const updated = { ...selectedProject, episodes: [...selectedProject.episodes, ep] };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
    setSelectedEpisode(ep.id);
  };

  // Scene CRUD
  const addScene = () => {
    if (!selectedProject || !selectedEpisode) return;
    const scene: Scene = {
      id: `scene_${Date.now()}`,
      title: `Scene ${selectedProject.episodes.find(e => e.id === selectedEpisode)?.scenes.length ?? 0 + 1}`,
      description: '',
      characters: [],
      camera: 'static shot',
      duration: 3,
      background: '',
      mood: 'Calm and peaceful',
      dialogue: '',
      seed: Math.floor(Math.random() * 9999999999),
      status: 'pending',
      progress: 0,
    };
    const updated = {
      ...selectedProject,
      episodes: selectedProject.episodes.map(e =>
        e.id === selectedEpisode ? { ...e, scenes: [...e.scenes, scene] } : e
      ),
    };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const updateSceneField = (sceneId: string, field: keyof Scene, value: string | number | string[]) => {
    if (!selectedProject || !selectedEpisode) return;
    const updated = {
      ...selectedProject,
      episodes: selectedProject.episodes.map(e =>
        e.id === selectedEpisode
          ? { ...e, scenes: e.scenes.map(s => s.id === sceneId ? { ...s, [field]: value } : s) }
          : e
      ),
    };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  const deleteScene = (sceneId: string) => {
    if (!selectedProject || !selectedEpisode) return;
    const updated = {
      ...selectedProject,
      episodes: selectedProject.episodes.map(e =>
        e.id === selectedEpisode ? { ...e, scenes: e.scenes.filter(s => s.id !== sceneId) } : e
      ),
    };
    setSelectedProject(updated);
    setProjects(prev => prev.map(p => p.id === selectedProject.id ? updated : p));
  };

  // Stats
  const stats = {
    projects: projects.length,
    episodes: projects.reduce((a, p) => a + p.episodes.length, 0),
    scenesDone: projects.reduce((a, p) => a + p.episodes.reduce((b, e) => b + e.scenes.filter(s => s.status === 'done').length, 0), 0),
    scenesTotal: projects.reduce((a, p) => a + p.episodes.reduce((b, e) => b + e.scenes.length, 0), 0),
    characters: projects.reduce((a, p) => a + p.characters.length, 0),
    duration: projects.reduce((a, p) => a + p.episodes.reduce((b, e) => b + e.scenes.reduce((c, s) => c + s.duration, 0), 0), 0),
  };

  /* ============================================
     RENDER FUNCTIONS
  ============================================= */

  // Render Dashboard
  const renderDashboard = () => (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-purple-900 to-pink-900 rounded-2xl p-6">
        <h2 className="text-2xl font-bold mb-2">🎬 LTX-2 Anime Agent</h2>
        <p className="text-purple-200">AI-Powered Local Anime Video Creation Studio</p>
        <p className="text-purple-300 text-sm mt-1">Create anime series with character consistency using ComfyUI + Ollama</p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {[
          { label: 'Projects', value: stats.projects, icon: '📁', color: 'blue' },
          { label: 'Episodes', value: stats.episodes, icon: '📺', color: 'purple' },
          { label: 'Scenes Done', value: `${stats.scenesDone}/${stats.scenesTotal}`, icon: '🎬', color: 'green' },
          { label: 'Characters', value: stats.characters, icon: '🎭', color: 'pink' },
          { label: 'Total Duration', value: `${stats.duration}s`, icon: '⏱️', color: 'yellow' },
          { label: 'Est. Size', value: `${(stats.duration * 0.5).toFixed(0)}MB`, icon: '💾', color: 'cyan' },
        ].map((s, i) => (
          <div key={i} className="bg-gray-800 rounded-xl p-4 text-center">
            <div className="text-2xl mb-1">{s.icon}</div>
            <div className="text-2xl font-bold">{s.value}</div>
            <div className="text-xs text-gray-400">{s.label}</div>
          </div>
        ))}
      </div>

      {/* Connection Status */}
      <div className="bg-gray-800 rounded-xl p-5">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold">🔌 System Status</h3>
          <button onClick={checkConnections} className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded-lg text-sm">
            🔄 Reconnect
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className={`p-4 rounded-lg border ${connections.comfyui === 'connected' ? 'bg-green-900/30 border-green-600' : connections.comfyui === 'checking' ? 'bg-yellow-900/30 border-yellow-600' : 'bg-red-900/30 border-red-600'}`}>
            <div className="flex items-center gap-2 mb-2">
              <span className={`w-3 h-3 rounded-full ${connections.comfyui === 'connected' ? 'bg-green-500' : connections.comfyui === 'checking' ? 'bg-yellow-500' : 'bg-red-500'}`} />
              <span className="font-bold">ComfyUI</span>
              <span className="text-xs text-gray-400">({connections.comfyuiUrl})</span>
            </div>
            {connections.comfyui === 'connected' ? (
              <div className="text-sm space-y-1">
                <p>🎮 {connections.gpu} ({connections.gpuMemory})</p>
                <p>📦 Models: {connections.comfyuiModels.length || 'None found'}</p>
                <p>📦 VAEs: {connections.comfyuiVAEs.length || 'None found'}</p>
                <p className="flex gap-2">
                  <span className={connections.hasVHS ? 'text-green-400' : 'text-red-400'}>VHS: {connections.hasVHS ? '✓' : '✗'}</span>
                  <span className={connections.hasGGUF ? 'text-green-400' : 'text-yellow-400'}>GGUF: {connections.hasGGUF ? '✓' : 'N/A'}</span>
                </p>
              </div>
            ) : (
              <p className="text-sm text-gray-400">
                {connections.comfyui === 'checking' ? 'Checking...' : 'Not connected. Start ComfyUI and click Reconnect.'}
              </p>
            )}
          </div>
          <div className={`p-4 rounded-lg border ${connections.ollama === 'connected' ? 'bg-green-900/30 border-green-600' : connections.ollama === 'checking' ? 'bg-yellow-900/30 border-yellow-600' : 'bg-red-900/30 border-red-600'}`}>
            <div className="flex items-center gap-2 mb-2">
              <span className={`w-3 h-3 rounded-full ${connections.ollama === 'connected' ? 'bg-green-500' : connections.ollama === 'checking' ? 'bg-yellow-500' : 'bg-red-500'}`} />
              <span className="font-bold">Ollama</span>
              <span className="text-xs text-gray-400">({connections.ollamaUrl})</span>
            </div>
            {connections.ollama === 'connected' ? (
              <div className="text-sm space-y-1">
                <p>🤖 Models: {connections.ollamaModels.length}</p>
                {connections.ollamaModels.length > 0 && (
                  <p className="text-gray-400">{connections.ollamaModels.slice(0, 3).join(', ')}</p>
                )}
                {connections.ollamaModels.length === 0 && (
                  <p className="text-yellow-400">Run: ollama pull llama3.2</p>
                )}
              </div>
            ) : (
              <p className="text-sm text-gray-400">
                {connections.ollama === 'checking' ? 'Checking...' : 'Not connected. Run: ollama serve'}
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <button onClick={() => setActiveTab('create')} className="bg-purple-600 hover:bg-purple-700 p-4 rounded-xl text-center">
          <div className="text-3xl mb-2">➕</div>
          <div className="font-bold">New Project</div>
        </button>
        <button onClick={() => setActiveTab('guide')} className="bg-blue-600 hover:bg-blue-700 p-4 rounded-xl text-center">
          <div className="text-3xl mb-2">📖</div>
          <div className="font-bold">Setup Guide</div>
        </button>
        <button onClick={() => setActiveTab('settings')} className="bg-gray-700 hover:bg-gray-600 p-4 rounded-xl text-center">
          <div className="text-3xl mb-2">⚙️</div>
          <div className="font-bold">Settings</div>
        </button>
        <button onClick={() => setShowLog(true)} className="bg-gray-700 hover:bg-gray-600 p-4 rounded-xl text-center">
          <div className="text-3xl mb-2">📋</div>
          <div className="font-bold">Logs ({logs.length})</div>
        </button>
      </div>

      {/* Projects List */}
      <div>
        <h3 className="text-lg font-bold mb-4">📁 Your Projects</h3>
        {projects.length === 0 ? (
          <div className="bg-gray-800 rounded-xl p-12 text-center">
            <p className="text-4xl mb-3">🎬</p>
            <p className="text-gray-400 mb-4">No projects yet. Create your first anime project!</p>
            <button onClick={() => setActiveTab('create')} className="bg-purple-600 hover:bg-purple-700 px-6 py-3 rounded-lg">
              Create Project
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {projects.map(project => {
              const eps = project.episodes.length;
              const scenes = project.episodes.reduce((a, e) => a + e.scenes.length, 0);
              const done = project.episodes.reduce((a, e) => a + e.scenes.filter(s => s.status === 'done').length, 0);
              const duration = project.episodes.reduce((a, e) => a + e.scenes.reduce((b, s) => b + s.duration, 0), 0);
              return (
                <div key={project.id} className="bg-gray-800 hover:bg-gray-750 rounded-xl p-5 border border-gray-700 cursor-pointer"
                  onClick={() => { setSelectedProject(project); setSelectedEpisode(null); setActiveTab('project'); }}>
                  <div className="flex justify-between items-start">
                    <div>
                      <h4 className="text-lg font-bold">{project.name}</h4>
                      <p className="text-sm text-gray-400 mt-1">{project.description.substring(0, 80)}...</p>
                      <div className="flex gap-4 text-sm text-gray-400 mt-3">
                        <span>📺 {eps} eps</span>
                        <span>🎬 {done}/{scenes} scenes</span>
                        <span>🎭 {project.characters.length} chars</span>
                        <span>⏱️ {duration}s</span>
                      </div>
                    </div>
                    <button onClick={(e) => { e.stopPropagation(); deleteProject(project.id); }}
                      className="text-red-400 hover:text-red-300 p-1">🗑️</button>
                  </div>
                  {scenes > 0 && (
                    <div className="mt-3 bg-gray-700 rounded-full h-2">
                      <div className="bg-green-500 h-2 rounded-full transition-all" style={{ width: `${scenes > 0 ? (done / scenes) * 100 : 0}%` }} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );

  // Render Create Project
  const renderCreateProject = () => {
    const [name, setName] = useState('');
    const [desc, setDesc] = useState('');
    const [style, setStyle] = useState('Anime Classic');

    return (
      <div className="max-w-2xl mx-auto space-y-6">
        <h2 className="text-2xl font-bold">➕ Create New Project</h2>
        <div className="bg-gray-800 rounded-xl p-6 space-y-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Project Name</label>
            <input value={name} onChange={e => setName(e.target.value)} placeholder="My Anime Series"
              className="w-full bg-gray-700 rounded-lg px-4 py-3 text-lg" />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Story Description</label>
            <textarea value={desc} onChange={e => setDesc(e.target.value)} rows={4}
              placeholder="Describe your anime story, main characters, and setting..."
              className="w-full bg-gray-700 rounded-lg px-4 py-3" />
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-2">Anime Style</label>
            <div className="grid grid-cols-3 gap-2">
              {Object.keys(STYLE_PRESETS).map(s => (
                <button key={s} onClick={() => setStyle(s)}
                  className={`px-3 py-2 rounded-lg text-sm ${style === s ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'}`}>
                  {s}
                </button>
              ))}
            </div>
          </div>
          <button onClick={() => { if (name && desc) createProject(name, desc, style); }}
            disabled={!name || !desc}
            className="w-full bg-purple-600 hover:bg-purple-700 disabled:bg-gray-600 py-3 rounded-lg text-lg font-bold">
            🎬 Create Project
          </button>
        </div>
      </div>
    );
  };

  // Render Project
  const renderProject = () => {
    if (!selectedProject) return null;
    const episode = selectedProject.episodes.find(e => e.id === selectedEpisode);

    return (
      <div className="space-y-6">
        {/* Project Header */}
        <div className="flex items-center gap-4">
          <button onClick={() => { setSelectedProject(null); setSelectedEpisode(null); setActiveTab('dashboard'); }}
            className="text-gray-400 hover:text-white text-xl">←</button>
          <div>
            <h2 className="text-2xl font-bold">{selectedProject.name}</h2>
            <p className="text-gray-400">{selectedProject.style} Style</p>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 bg-gray-800 rounded-lg p-1">
          <button onClick={() => setSelectedEpisode(null)}
            className={`flex-1 py-2 px-4 rounded font-medium ${!selectedEpisode ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}>
            🎭 Characters ({selectedProject.characters.length})
          </button>
          <button onClick={() => setSelectedEpisode(selectedProject.episodes[0]?.id || null)}
            className={`flex-1 py-2 px-4 rounded font-medium ${selectedEpisode ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white'}`}>
            📺 Episodes ({selectedProject.episodes.length})
          </button>
        </div>

        {/* Characters */}
        {!selectedEpisode && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">Characters</h3>
              <div className="flex gap-2">
                <button onClick={aiGenerateCharacters} disabled={connections.ollama !== 'connected' || aiGenerating}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 px-4 py-2 rounded-lg text-sm">
                  {aiGenerating ? '⏳ Generating...' : '🤖 AI Generate'}
                </button>
                <button onClick={addCharacter} className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg text-sm">
                  + Add Character
                </button>
              </div>
            </div>

            {selectedProject.characters.length === 0 ? (
              <div className="text-center py-12 bg-gray-800 rounded-xl">
                <p className="text-4xl mb-2">👥</p>
                <p className="text-gray-400">No characters yet. Click "+ Add" or "🤖 AI Generate"</p>
              </div>
            ) : (
              selectedProject.characters.map(char => (
                <div key={char.id} className="bg-gray-800 rounded-lg p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-12 h-12 rounded-full flex items-center justify-center text-white font-bold text-xl flex-shrink-0"
                      style={{ backgroundColor: char.color }}>
                      {char.name[0]?.toUpperCase()}
                    </div>
                    <div className="flex-1 space-y-2">
                      <div className="flex gap-2">
                        <input value={char.name} onChange={e => updateCharacter(char.id, 'name', e.target.value)}
                          className="flex-1 bg-gray-700 rounded px-3 py-1.5 font-bold" />
                        <select value={char.role} onChange={e => updateCharacter(char.id, 'role', e.target.value)}
                          className="bg-gray-700 rounded px-3 py-1.5">
                          <option value="protagonist">Protagonist</option>
                          <option value="antagonist">Antagonist</option>
                          <option value="supporting">Supporting</option>
                          <option value="minor">Minor</option>
                        </select>
                        <button onClick={() => deleteCharacter(char.id)} className="text-red-400 hover:text-red-300 px-2">✕</button>
                      </div>
                      <textarea value={char.appearance} onChange={e => updateCharacter(char.id, 'appearance', e.target.value)}
                        placeholder="Detailed appearance (hair, eyes, clothing...)" rows={2}
                        className="w-full bg-gray-700 rounded px-3 py-1.5 text-sm" />
                      <input value={char.consistentPrompt} onChange={e => updateCharacter(char.id, 'consistentPrompt', e.target.value)}
                        placeholder="Consistency prompt (e.g., 'same blue-haired girl')"
                        className="w-full bg-gray-700 rounded px-3 py-1.5 text-sm" />
                    </div>
                  </div>
                </div>
              ))
            )}
            <div className="bg-blue-900/30 border border-blue-600 rounded-xl p-4">
              <p className="text-sm text-blue-300">💡 <strong>Tip:</strong> Include specific details (hair color, eye color, clothing) for character consistency across scenes.</p>
            </div>
          </div>
        )}

        {/* Episodes */}
        {selectedEpisode && episode && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-3">
                <button onClick={() => setSelectedEpisode(null)} className="text-gray-400 hover:text-white">←</button>
                <h3 className="text-lg font-bold">{episode.title}</h3>
              </div>
              <div className="flex gap-2">
                <button onClick={aiGenerateStory} disabled={connections.ollama !== 'connected' || aiGenerating}
                  className="bg-green-600 hover:bg-green-700 disabled:bg-gray-600 px-4 py-2 rounded-lg text-sm">
                  {aiGenerating ? '⏳ Generating...' : '🤖 AI Story'}
                </button>
                <button onClick={addScene} className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg text-sm">
                  + Scene
                </button>
                <button onClick={generateEpisode} disabled={generating || connections.comfyui !== 'connected'}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-4 py-2 rounded-lg text-sm">
                  {generating ? '⏳ Generating...' : '🎬 Generate All'}
                </button>
              </div>
            </div>

            {/* Episode tabs */}
            <div className="flex gap-2 overflow-x-auto pb-2">
              {selectedProject.episodes.map(ep => (
                <button key={ep.id} onClick={() => setSelectedEpisode(ep.id)}
                  className={`px-4 py-2 rounded whitespace-nowrap ${ep.id === selectedEpisode ? 'bg-purple-600' : 'bg-gray-700 hover:bg-gray-600'}`}>
                  {ep.title} ({ep.scenes.length})
                </button>
              ))}
              <button onClick={addEpisode} className="px-4 py-2 rounded bg-gray-700 text-gray-400 hover:text-white">+ Episode</button>
            </div>

            {/* Scenes */}
            {episode.scenes.length === 0 ? (
              <div className="text-center py-12 bg-gray-800 rounded-xl">
                <p className="text-4xl mb-2">🎬</p>
                <p className="text-gray-400">No scenes yet. Click "+ Scene" or "🤖 AI Story"</p>
              </div>
            ) : (
              episode.scenes.map((scene, si) => (
                <div key={scene.id} className={`bg-gray-800 rounded-lg p-4 border-l-4 ${
                  scene.status === 'done' ? 'border-green-500' :
                  scene.status === 'generating' ? 'border-yellow-500' :
                  scene.status === 'error' ? 'border-red-500' : 'border-gray-600'
                }`}>
                  <div className="flex justify-between items-start mb-3">
                    <div>
                      <h4 className="font-bold">Scene {si + 1}: {scene.title}</h4>
                      <p className="text-sm text-gray-400">{scene.description || 'No description'}</p>
                    </div>
                    <div className="flex gap-2 items-center">
                      <span className={`text-xs px-2 py-1 rounded ${
                        scene.status === 'done' ? 'bg-green-600' :
                        scene.status === 'generating' ? 'bg-yellow-600' :
                        scene.status === 'error' ? 'bg-red-600' : 'bg-gray-600'
                      }`}>
                        {scene.status === 'generating' ? `${scene.progress}%` : scene.status}
                      </span>
                      <button onClick={() => downloadWorkflow(scene)} className="text-xs bg-gray-700 hover:bg-gray-600 px-2 py-1 rounded">📥</button>
                      <button onClick={() => queueScene(scene, selectedProject.episodes.findIndex(e => e.id === selectedEpisode), si)}
                        disabled={generating || connections.comfyui !== 'connected'}
                        className="text-xs bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-2 py-1 rounded">▶️</button>
                      <button onClick={() => deleteScene(scene.id)} className="text-xs text-red-400 hover:text-red-300 px-1">✕</button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <input value={scene.title} onChange={e => updateSceneField(scene.id, 'title', e.target.value)}
                      placeholder="Scene title" className="bg-gray-700 rounded px-3 py-2" />
                    <select value={scene.mood} onChange={e => updateSceneField(scene.id, 'mood', e.target.value)}
                      className="bg-gray-700 rounded px-3 py-2">
                      {MOODS.map(m => <option key={m} value={m}>{m}</option>)}
                    </select>
                    <textarea value={scene.description} onChange={e => updateSceneField(scene.id, 'description', e.target.value)}
                      placeholder="What happens in this scene..." rows={2}
                      className="bg-gray-700 rounded px-3 py-2 md:col-span-2" />
                    <input value={scene.background} onChange={e => updateSceneField(scene.id, 'background', e.target.value)}
                      placeholder="Background setting" className="bg-gray-700 rounded px-3 py-2" />
                    <select value={scene.camera} onChange={e => updateSceneField(scene.id, 'camera', e.target.value)}
                      className="bg-gray-700 rounded px-3 py-2">
                      {CAMERA_MOVEMENTS.map(c => <option key={c} value={c}>{c}</option>)}
                    </select>
                    <div className="flex gap-2 items-center">
                      <input type="number" value={scene.duration}
                        onChange={e => updateSceneField(scene.id, 'duration', Math.max(1, Math.min(10, parseInt(e.target.value) || 3)))}
                        min={1} max={10} className="bg-gray-700 rounded px-3 py-2 w-20" />
                      <span className="text-gray-400">seconds</span>
                    </div>
                    <input value={scene.dialogue} onChange={e => updateSceneField(scene.id, 'dialogue', e.target.value)}
                      placeholder="Optional dialogue" className="bg-gray-700 rounded px-3 py-2" />

                    {/* Character selection */}
                    <div className="md:col-span-2">
                      <label className="text-xs text-gray-400 mb-1 block">Characters in scene:</label>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.characters.map(char => (
                          <button key={char.id}
                            onClick={() => {
                              const chars = scene.characters.includes(char.id)
                                ? scene.characters.filter(c => c !== char.id)
                                : [...scene.characters, char.id];
                              updateSceneField(scene.id, 'characters', chars);
                            }}
                            className={`text-xs px-3 py-1.5 rounded border ${
                              scene.characters.includes(char.id) ? 'border-purple-500 bg-purple-600/30' : 'border-gray-600 bg-gray-700'
                            }`}>
                            <span className="inline-block w-2 h-2 rounded-full mr-1" style={{ backgroundColor: char.color }} />
                            {char.name}
                          </button>
                        ))}
                        {selectedProject.characters.length === 0 && (
                          <p className="text-xs text-gray-500">Add characters first</p>
                        )}
                      </div>
                    </div>

                    {/* Progress bar */}
                    {scene.status === 'generating' && (
                      <div className="md:col-span-2">
                        <div className="bg-gray-700 rounded-full h-2">
                          <div className="bg-yellow-500 h-2 rounded-full transition-all" style={{ width: `${scene.progress}%` }} />
                        </div>
                      </div>
                    )}
                    {scene.error && (
                      <p className="md:col-span-2 text-xs text-red-400">❌ {scene.error}</p>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        )}

        {/* Episodes List */}
        {!selectedEpisode && (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-bold">Episodes</h3>
              <div className="flex gap-2">
                <button onClick={downloadBatchScript} disabled={selectedProject.episodes.length === 0}
                  className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-600 px-4 py-2 rounded-lg text-sm">
                  📥 Batch Script
                </button>
                <button onClick={addEpisode} className="bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-lg text-sm">
                  + Episode
                </button>
              </div>
            </div>
            {selectedProject.episodes.length === 0 ? (
              <div className="text-center py-12 bg-gray-800 rounded-xl">
                <p className="text-4xl mb-2">📺</p>
                <p className="text-gray-400">No episodes yet. Click "+ Episode"</p>
              </div>
            ) : (
              selectedProject.episodes.map(ep => {
                const done = ep.scenes.filter(s => s.status === 'done').length;
                const duration = ep.scenes.reduce((a, s) => a + s.duration, 0);
                return (
                  <div key={ep.id} onClick={() => setSelectedEpisode(ep.id)}
                    className="bg-gray-800 hover:bg-gray-700 rounded-lg p-4 cursor-pointer">
                    <div className="flex justify-between items-center">
                      <div>
                        <h4 className="font-bold text-lg">{ep.title}</h4>
                        <div className="flex gap-4 text-sm text-gray-400 mt-1">
                          <span>🎬 {ep.scenes.length} scenes</span>
                          <span>✅ {done}/{ep.scenes.length} done</span>
                          <span>⏱️ ~{duration}s</span>
                        </div>
                      </div>
                      <span className="text-2xl">→</span>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    );
  };

  // Render Settings
  const renderSettings = () => (
    <div className="max-w-2xl mx-auto space-y-6">
      <h2 className="text-2xl font-bold">⚙️ Settings</h2>

      {/* Connection URLs */}
      <div className="bg-gray-800 rounded-xl p-5 space-y-4">
        <h3 className="font-bold">🔗 Connection URLs</h3>
        <div>
          <label className="block text-sm text-gray-400 mb-1">ComfyUI URL</label>
          <input value={connections.comfyuiUrl}
            onChange={e => setConnections(p => ({ ...p, comfyuiUrl: e.target.value }))}
            className="w-full bg-gray-700 rounded px-4 py-2" />
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1">Ollama URL</label>
          <input value={connections.ollamaUrl}
            onChange={e => setConnections(p => ({ ...p, ollamaUrl: e.target.value }))}
            className="w-full bg-gray-700 rounded px-4 py-2" />
        </div>
        <button onClick={checkConnections} className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded">
          🔄 Reconnect
        </button>
      </div>

      {/* Video Settings */}
      <div className="bg-gray-800 rounded-xl p-5 space-y-4">
        <h3 className="font-bold">🎬 Video Settings</h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Resolution Preset</label>
            <select value={`${settings.width}x${settings.height}`}
              onChange={e => { const [w, h] = e.target.value.split('x').map(Number); setSettings(p => ({ ...p, width: w, height: h })); }}
              className="w-full bg-gray-700 rounded px-4 py-2">
              <option value="512x384">512x384 (Fast, Low VRAM)</option>
              <option value="512x512">512x512 (Square)</option>
              <option value="640x480">640x480 (4:3)</option>
              <option value="768x576">768x576 (High Quality)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">FPS</label>
            <select value={settings.fps} onChange={e => setSettings(p => ({ ...p, fps: Number(e.target.value) }))}
              className="w-full bg-gray-700 rounded px-4 py-2">
              <option value={12}>12 FPS (Fast)</option>
              <option value={24}>24 FPS (Standard)</option>
              <option value={30}>30 FPS (Smooth)</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Sampling Steps ({settings.steps})</label>
            <input type="range" min={4} max={24} value={settings.steps}
              onChange={e => setSettings(p => ({ ...p, steps: Number(e.target.value) }))}
              className="w-full" />
            <div className="flex justify-between text-xs text-gray-500">
              <span>4 (Fast)</span><span>24 (Quality)</span>
            </div>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">CFG Scale ({settings.cfg})</label>
            <input type="range" min={1} max={10} step={0.5} value={settings.cfg}
              onChange={e => setSettings(p => ({ ...p, cfg: Number(e.target.value) }))}
              className="w-full" />
          </div>
        </div>
      </div>

      {/* Model Settings */}
      <div className="bg-gray-800 rounded-xl p-5 space-y-4">
        <h3 className="font-bold">🤖 Model Files</h3>
        <div>
          <label className="block text-sm text-gray-400 mb-1">UNet / Checkpoint Model</label>
          {connections.comfyuiModels.length > 0 ? (
            <select value={settings.modelFile}
              onChange={e => setSettings(p => ({ ...p, modelFile: e.target.value }))}
              className="w-full bg-gray-700 rounded px-4 py-2">
              {connections.comfyuiModels.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          ) : (
            <input value={settings.modelFile}
              onChange={e => setSettings(p => ({ ...p, modelFile: e.target.value }))}
              placeholder="ltx-video-2b-Q4_K_M.gguf"
              className="w-full bg-gray-700 rounded px-4 py-2" />
          )}
        </div>
        <div>
          <label className="block text-sm text-gray-400 mb-1">VAE File</label>
          {connections.comfyuiVAEs.length > 0 ? (
            <select value={settings.vaeFile}
              onChange={e => setSettings(p => ({ ...p, vaeFile: e.target.value }))}
              className="w-full bg-gray-700 rounded px-4 py-2">
              {connections.comfyuiVAEs.map(m => <option key={m} value={m}>{m}</option>)}
            </select>
          ) : (
            <input value={settings.vaeFile}
              onChange={e => setSettings(p => ({ ...p, vaeFile: e.target.value }))}
              placeholder="ltx-video-2b.safetensors"
              className="w-full bg-gray-700 rounded px-4 py-2" />
          )}
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm text-gray-400 mb-1">Sampler</label>
            <select value={settings.sampler} onChange={e => setSettings(p => ({ ...p, sampler: e.target.value }))}
              className="w-full bg-gray-700 rounded px-4 py-2">
              <option value="euler">Euler</option>
              <option value="euler_ancestral">Euler Ancestral</option>
              <option value="dpmpp_2m">DPM++ 2M</option>
              <option value="dpmpp_sde">DPM++ SDE</option>
            </select>
          </div>
          <div>
            <label className="block text-sm text-gray-400 mb-1">Scheduler</label>
            <select value={settings.scheduler} onChange={e => setSettings(p => ({ ...p, scheduler: e.target.value }))}
              className="w-full bg-gray-700 rounded px-4 py-2">
              <option value="normal">Normal</option>
              <option value="karras">Karras</option>
              <option value="exponential">Exponential</option>
            </select>
          </div>
        </div>
      </div>

      {/* VRAM Tips */}
      <div className="bg-yellow-900/30 border border-yellow-600 rounded-xl p-5">
        <h3 className="font-bold text-yellow-400 mb-2">💡 GTX 1660 Ti (6GB) Tips</h3>
        <ul className="text-sm text-yellow-200 space-y-1">
          <li>• Use 512x384 resolution for fastest generation</li>
          <li>• Keep steps at 8 for good speed/quality balance</li>
          <li>• Start ComfyUI with --lowvram flag</li>
          <li>• GGUF Q4_K_M model fits in 6GB VRAM</li>
          <li>• Close other GPU applications while generating</li>
        </ul>
      </div>
    </div>
  );

  // Render Guide
  const renderGuide = () => (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-900 to-purple-900 rounded-2xl p-6">
        <h2 className="text-2xl font-bold mb-2">📖 Complete Setup Guide</h2>
        <p className="text-blue-200">Step-by-step instructions for GTX 1660 Ti (6GB VRAM, 16GB RAM)</p>
      </div>

      {SETUP_GUIDE.map((step, i) => (
        <div key={i} className="bg-gray-800 rounded-xl overflow-hidden">
          <button onClick={() => setExpandedGuide(expandedGuide === i ? null : i)}
            className="w-full flex items-center gap-4 p-5 text-left hover:bg-gray-750">
            <span className="text-3xl">{step.icon}</span>
            <div className="flex-1">
              <h3 className="font-bold text-lg">Step {i + 1}: {step.title}</h3>
              <p className="text-sm text-gray-400">{step.description}</p>
            </div>
            <span className="text-gray-400">{expandedGuide === i ? '▲' : '▼'}</span>
          </button>
          {expandedGuide === i && (
            <div className="px-5 pb-5 space-y-3">
              <div className="bg-gray-900 rounded-lg p-4 font-mono text-sm space-y-1">
                {step.steps.map((s, j) => (
                  <p key={j} className={s.startsWith('#') ? 'text-gray-500' : 'text-green-400'}>{s}</p>
                ))}
              </div>
              {step.tip && (
                <div className="bg-blue-900/30 border border-blue-600 rounded-lg p-3">
                  <p className="text-sm text-blue-300">💡 {step.tip}</p>
                </div>
              )}
            </div>
          )}
        </div>
      ))}

      {/* Troubleshooting */}
      <div className="bg-gray-800 rounded-xl p-5">
        <h3 className="text-lg font-bold mb-4">🔧 Troubleshooting</h3>
        <div className="space-y-3">
          {TROUBLESHOOTING.map((t, i) => (
            <div key={i} className="bg-gray-900 rounded-lg p-3">
              <p className="font-bold text-red-400">{t.issue}</p>
              <p className="text-sm text-gray-300 mt-1">{t.fix}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  // Navigation
  const navItems = [
    { id: 'dashboard', label: '🏠 Dashboard' },
    { id: 'create', label: '➕ New Project' },
    { id: 'settings', label: '⚙️ Settings' },
    { id: 'guide', label: '📖 Guide' },
  ];

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="bg-gray-800 border-b border-gray-700 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('dashboard')}>
            <span className="text-2xl">🎬</span>
            <div>
              <h1 className="text-xl font-bold">LTX-2 Anime Agent</h1>
              <p className="text-xs text-gray-400">Local AI Video Studio</p>
            </div>
          </div>
          <nav className="flex gap-2">
            {navItems.map(item => (
              <button key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`px-3 py-1.5 rounded text-sm ${
                  activeTab === item.id ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}>
                {item.label}
              </button>
            ))}
            {selectedProject && (
              <button onClick={() => setActiveTab('project')}
                className={`px-3 py-1.5 rounded text-sm ${
                  activeTab === 'project' ? 'bg-purple-600 text-white' : 'text-gray-400 hover:text-white hover:bg-gray-700'
                }`}>
                📁 {selectedProject.name}
              </button>
            )}
          </nav>
        </div>
      </header>

      {/* Main */}
      <main className="max-w-7xl mx-auto px-4 py-6">
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'create' && renderCreateProject()}
        {activeTab === 'project' && renderProject()}
        {activeTab === 'settings' && renderSettings()}
        {activeTab === 'guide' && renderGuide()}
      </main>

      {/* Log Panel */}
      {logs.length > 0 && !showLog && (
        <button onClick={() => setShowLog(true)}
          className="fixed bottom-4 right-4 bg-gray-700 hover:bg-gray-600 px-4 py-2 rounded-full shadow-lg flex items-center gap-2">
          📋 {logs.length}
        </button>
      )}
      {showLog && (
        <div className="fixed bottom-4 right-4 w-96 max-h-80 bg-gray-800 rounded-xl shadow-2xl border border-gray-700 overflow-hidden z-50">
          <div className="flex justify-between items-center px-4 py-2 bg-gray-700">
            <span className="font-bold">📋 Activity Log</span>
            <button onClick={() => setShowLog(false)} className="text-gray-400 hover:text-white">✕</button>
          </div>
          <div className="p-3 overflow-y-auto max-h-64 space-y-1 text-xs font-mono">
            {logs.map((log, i) => (
              <p key={i} className={
                log.includes('✅') ? 'text-green-400' :
                log.includes('❌') ? 'text-red-400' :
                log.includes('⚠️') ? 'text-yellow-400' :
                log.includes('💡') ? 'text-blue-400' : 'text-gray-400'
              }>{log}</p>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
